#pragma once

#include <mapix.h>
#include <mapispi.h>
#include <mapiutil.h>
#include <mapiform.h>
#include <stdio.h>
#include <tchar.h>
#include <strsafe.h>
#include <imessage.h>
#include "edkmdb.h"
#include "MFCMAPI.h"
