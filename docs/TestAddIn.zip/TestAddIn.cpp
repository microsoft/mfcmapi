#include "TestAddIn.h"
#include <initguid.h>

LPADDINLOG AddInLog = NULL;
WCHAR* g_szAddInName = L"TestAddIn";

BOOL WINAPI DllMain(HINSTANCE /*hinstDLL*/, DWORD /*fdwReason*/, LPVOID /*lpvReserved*/)
{
	return true;
}

// LoadAddIn - Let the add-in know we're here, get its name.
// If this function is not present, we won't load the add-in
void STDMETHODCALLTYPE LoadAddIn(LPWSTR* szName)
{
	// Get our logging routine
	HMODULE hMod = GetModuleHandle(NULL);
	AddInLog = (LPADDINLOG) GetProcAddress(hMod,szAddInLog);
	AddInLog(true,L"%s loading\n",g_szAddInName);
	*szName = g_szAddInName;
}

// UnloadAddIn - let the add-in know we're done - it should free any resources it has allocated
void STDMETHODCALLTYPE UnloadAddIn()
{
	AddInLog(true,L"%s unloading\n",g_szAddInName);
}

_MenuItem g_MyMenus[] = {
	{L"Load MAPI",L"Force MAPI to load",MENU_CONTEXT_ALL_WINDOWS,0,0},
	{L"Get MAPI Handle",L"Check MAPI load status",MENU_CONTEXT_ALL_WINDOWS,0,1},
	{L"Test Complex Dialog",L"Test the complex dialog",MENU_CONTEXT_ALL_WINDOWS,0,2},
	{L"All Windows, no flags",L"All Windows",MENU_CONTEXT_ALL_WINDOWS,NULL,3},
	{L"MENU_FLAGS_SINGLESELECT",L"All Windows",MENU_CONTEXT_ALL_WINDOWS,MENU_FLAGS_SINGLESELECT,4},
	{L"MENU_FLAGS_SINGLESELECT|MENU_FLAGS_ROW",L"All Windows",MENU_CONTEXT_ALL_WINDOWS,MENU_FLAGS_SINGLESELECT|MENU_FLAGS_ROW,5},
	{L"Regular folder",L"All Folders",   MENU_CONTEXT_ALL_FOLDER,MENU_FLAGS_FOLDER_REG,6},
	{L"Deleted folder",L"All Folders",   MENU_CONTEXT_ALL_FOLDER,MENU_FLAGS_DELETED,7},
	{L"Associated folder",L"All Folders",MENU_CONTEXT_ALL_FOLDER,MENU_FLAGS_FOLDER_ASSOC,8},
	{L"Property menu",L"Property only",MENU_CONTEXT_PROPERTY,NULL,9},
	{L"Bad flag combo",L"All Windows",MENU_CONTEXT_ALL_WINDOWS,MENU_FLAGS_MULTISELECT|MENU_FLAGS_SINGLESELECT,10}, // this is an invalid combination of flags - should never appear in the UI
	};

// GetMenus - returns static array of menu information - no function pointers - just context numbers
void STDMETHODCALLTYPE GetMenus(ULONG* lpulMenu, LPMENUITEM* lppMenu)
{
	if (!lpulMenu || !lppMenu) return;
	*lpulMenu = sizeof(g_MyMenus)/sizeof(_MenuItem);
	*lppMenu = g_MyMenus;
}

void DebugPrintAddInMenuParams(LPADDINMENUPARAMS lpParams)
{
	if (!lpParams) return;
	if (lpParams->lpAddInMenu)
	{
		AddInLog(true,L"Menu: \"%ws\"\n",lpParams->lpAddInMenu->szMenu);
		AddInLog(true,L"Help: \"%ws\"\n",lpParams->lpAddInMenu->szHelp);
		AddInLog(true,L"ID: 0x%08X\n",lpParams->lpAddInMenu->ulID);
		AddInLog(true,L"Context: 0x%08X\n",lpParams->lpAddInMenu->ulContext);
		AddInLog(true,L"Flags: 0x%08X\n",lpParams->lpAddInMenu->ulFlags);
	}
	AddInLog(true,L"Current context: 0x%08X\n",lpParams->ulAddInContext);
	if (lpParams->hWndParent) AddInLog(true,L"Got hWndParent 0x%08X\n",lpParams->hWndParent);
	if (lpParams->lpMAPISession) AddInLog(true,L"Got lpMAPISession\n");
	if (lpParams->lpMDB) AddInLog(true,L"Got lpMDB\n");
	if (lpParams->lpFolder) AddInLog(true,L"Got lpFolder\n");
	if (lpParams->lpMessage) AddInLog(true,L"Got lpMessage\n");
	if (lpParams->lpTable) AddInLog(true,L"Got lpTable\n");
	if (lpParams->lpAdrBook) AddInLog(true,L"Got lpAdrBook\n");
	if (lpParams->lpAbCont) AddInLog(true,L"Got lpAbCont\n");
	if (lpParams->lpMailUser) AddInLog(true,L"Got lpMailUser\n");
	if (lpParams->lpExchTbl) AddInLog(true,L"Got lpExchTbl\n");
	if (lpParams->lpFormContainer) AddInLog(true,L"Got lpFormContainer\n");
	if (lpParams->lpFormInfoProp) AddInLog(true,L"Got lpFormInfoProp\n");
	if (lpParams->lpProfSect) AddInLog(true,L"Got lpProfSect\n");
	if (lpParams->lpAttach) AddInLog(true,L"Got lpAttach\n");
	if (lpParams->ulPropTag) AddInLog(true,L"Got ulPropTag: 0x%08X\n",lpParams->ulPropTag);
	if (lpParams->lpRow) AddInLog(true,L"Got lpRow\n");
	if (lpParams->lpMAPIProp) AddInLog(true,L"Got lpMAPIProp\n");
}

_AddInDialogControl g_ParamControls[] = 
{
	{ADDIN_CTRL_EDIT_TEXT, true, false, false, 0, L"Menu", L"",0,0},// 0
	{ADDIN_CTRL_EDIT_TEXT, true, false, false, 0, L"Help", L"",0,0},// 1
	{ADDIN_CTRL_EDIT_NUM_HEX, true, false, false, 0, L"ID", L"",0,0},// 2
	{ADDIN_CTRL_EDIT_NUM_HEX, true, false, false, 0, L"Requested Context", L"",0,0},// 3
	{ADDIN_CTRL_EDIT_NUM_HEX, true, false, false, 0, L"Flags", L"",0,0},// 4
	{ADDIN_CTRL_EDIT_NUM_HEX, true, false, false, 0, L"Current Context", L"",0,0},// 5
	{ADDIN_CTRL_EDIT_NUM_HEX, true, false, false, 0, L"hWndParent", L"",0,0},// 6
	{ADDIN_CTRL_EDIT_TEXT, true, true, false, 0, L"MAPI Interfaces", L"",0,0},// 7
	{ADDIN_CTRL_EDIT_NUM_HEX, true, false, false, 0, L"ulPropTag", L"",0,0},// 8
	{ADDIN_CTRL_EDIT_NUM_HEX, true, false, false, 0, L"lpRow", L"",0,0},// 9
};
void DisplayAddInMenuParams(LPADDINMENUPARAMS lpParams)
{
	LPCOMPLEXDIALOG pfnComplexDialog = (LPCOMPLEXDIALOG) GetProcAddress(GetModuleHandle(NULL),szComplexDialog);
	LPFREEDIALOGRESULT pfnFreeDialogResult = (LPFREEDIALOGRESULT) GetProcAddress(GetModuleHandle(NULL),szFreeDialogResult);
	if (pfnComplexDialog && pfnFreeDialogResult)
	{
		HRESULT hRes = S_OK;
		_AddInDialog myDialog = {0};
		myDialog.szTitle = L"Menu Results";
		myDialog.szPrompt = L"This is what was passed to CallMenu";
		myDialog.ulButtonFlags = CEDITOR_BUTTON_OK;
		myDialog.ulNumControls = sizeof(g_ParamControls)/sizeof(_AddInDialogControl);
		myDialog.lpDialogControls = g_ParamControls;
		WCHAR szAddInLogString[4096];
		hRes = StringCchPrintfW(szAddInLogString, 4096,
			L"lpMAPISession = 0x%08X\r\n"
			L"lpMDB = 0x%08X\r\n"
			L"lpFolder = 0x%08X\r\n"
			L"lpMessage = 0x%08X\r\n"
			L"lpTable = 0x%08X\r\n"
			L"lpAdrBook = 0x%08X\r\n"
			L"lpAbCont = 0x%08X\r\n"
			L"lpMailUser = 0x%08X\r\n"
			L"lpExchTbl = 0x%08X\r\n"
			L"lpFormContainer = 0x%08X\r\n"
			L"lpFormInfoProp = 0x%08X\r\n"
			L"lpProfSect = 0x%08X\r\n"
			L"lpAttach = 0x%08X\r\n"
			L"lpMAPIProp = 0x%08X\r\n",
			lpParams->lpMAPISession,
			lpParams->lpMDB,
			lpParams->lpFolder,
			lpParams->lpMessage,
			lpParams->lpTable,
			lpParams->lpAdrBook,
			lpParams->lpAbCont,
			lpParams->lpMailUser,
			lpParams->lpExchTbl,
			lpParams->lpFormContainer,
			lpParams->lpFormInfoProp,
			lpParams->lpProfSect,
			lpParams->lpAttach,
			lpParams->lpMAPIProp);

		if (lpParams->lpAddInMenu)
		{
			g_ParamControls[0].szDefaultText = lpParams->lpAddInMenu->szMenu;
			g_ParamControls[1].szDefaultText = lpParams->lpAddInMenu->szHelp;
			g_ParamControls[2].ulDefaultNum = lpParams->lpAddInMenu->ulID;
			g_ParamControls[3].ulDefaultNum = lpParams->lpAddInMenu->ulContext;
			g_ParamControls[4].ulDefaultNum = lpParams->lpAddInMenu->ulFlags;
		}
		g_ParamControls[5].ulDefaultNum = lpParams->ulAddInContext;
		g_ParamControls[6].ulDefaultNum = (ULONG)lpParams->hWndParent;
		g_ParamControls[7].szDefaultText = szAddInLogString;
		g_ParamControls[8].ulDefaultNum = lpParams->ulPropTag;
		g_ParamControls[9].ulDefaultNum = (ULONG)lpParams->lpRow;
		pfnComplexDialog(&myDialog,NULL);
	}
}

_AddInDialogControl g_TestAddInControls[] = 
{
	{ADDIN_CTRL_CHECK, false, false, true, 0, L"Read Write Checkbox", L"",0,0},
	{ADDIN_CTRL_CHECK, true, false, false, 0, L"Read only Checkbox", L"",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Single line", L"This is a single line of text",0,0},
	{ADDIN_CTRL_EDIT_TEXT, true, false, false, 0, L"Single line, read only", L"This is a single line of text",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, true, false, 0, L"Multi line", L"This\r\nis\r\nmultiple\r\nlines",0,0},
	{ADDIN_CTRL_EDIT_NUM_DECIMAL, false, false, false, 42, L"Decimal", L"",0,0},
	{ADDIN_CTRL_EDIT_NUM_HEX, false, false, false, 0x42, L"Hex", L"",0,0},
	{ADDIN_CTRL_EDIT_BINARY, false, true, false, 0, L"Binary", L"",0,(LPBYTE)&g_TestAddInControls},
};
void TestComplexDialog()
{
	LPCOMPLEXDIALOG pfnComplexDialog = (LPCOMPLEXDIALOG) GetProcAddress(GetModuleHandle(NULL),szComplexDialog);
	LPFREEDIALOGRESULT pfnFreeDialogResult = (LPFREEDIALOGRESULT) GetProcAddress(GetModuleHandle(NULL),szFreeDialogResult);
	if (pfnComplexDialog && pfnFreeDialogResult)
	{
		_AddInDialog myDialog = {0};
		myDialog.szTitle = L"TestAddIn Rules!";
		myDialog.szPrompt = L"This is the test of an addin dialog\r\n\r\nThis is a second line.";
		myDialog.ulButtonFlags = CEDITOR_BUTTON_OK;
		myDialog.ulNumControls = sizeof(g_TestAddInControls)/sizeof(_AddInDialogControl);
		myDialog.lpDialogControls = g_TestAddInControls;
		g_TestAddInControls[7].cbBin = sizeof(g_TestAddInControls);

		LPADDINDIALOGRESULT lpDialogResult = NULL;

		pfnComplexDialog(&myDialog,&lpDialogResult);
		if (lpDialogResult)
		{
			ULONG i = 0;
			for (i = 0 ; i < lpDialogResult->ulNumControls ; i++)
			{
				switch (lpDialogResult->lpDialogControlResults[i].cType)
				{
				case ADDIN_CTRL_CHECK:
					AddInLog(true,L"%d = %d\n",i,lpDialogResult->lpDialogControlResults[i].bCheckState);
					break;
				case ADDIN_CTRL_EDIT_TEXT:
					AddInLog(true,L"%d = \"%ws\"\n",i,lpDialogResult->lpDialogControlResults[i].szText);
					break;
				case ADDIN_CTRL_EDIT_BINARY:
					AddInLog(true,L"%d = cb = 0x%08X, lpb = 0x%08X\n",i,
						lpDialogResult->lpDialogControlResults[i].cbBin,
						lpDialogResult->lpDialogControlResults[i].lpBin);
					break;
				case ADDIN_CTRL_EDIT_NUM_DECIMAL:
					AddInLog(true,L"%d = %d\n",i,lpDialogResult->lpDialogControlResults[i].ulVal);
					break;
				case ADDIN_CTRL_EDIT_NUM_HEX:
					AddInLog(true,L"%d = 0x%08X\n",i,lpDialogResult->lpDialogControlResults[i].ulVal);
					break;
				}
			}
		}
		pfnFreeDialogResult(lpDialogResult);
	}
}

// CallMenu - calls back to AddIn with a menu choice - addin will decode and invoke
HRESULT STDMETHODCALLTYPE CallMenu(
				 LPADDINMENUPARAMS lpParams	// Everything the add-in needs to know
				 )
{
	HRESULT	hRes = S_OK;
	AddInLog(true,L"CallMenu: Congratulations! You have just extended MFCMAPI!\n");
	if (!lpParams) return MAPI_E_INVALID_PARAMETER;
	DebugPrintAddInMenuParams(lpParams);

	LPSIMPLEDIALOG pfnSimpleDialog = (LPSIMPLEDIALOG) GetProcAddress(GetModuleHandle(NULL),szSimpleDialog);

	if (lpParams->lpAddInMenu)
	{
		switch (lpParams->lpAddInMenu->ulID)
		{
		case 0 : 
			{
				if (pfnSimpleDialog) pfnSimpleDialog(g_szAddInName,L"Loading MAPI");
				LPGETMAPIMODULE pfnGetMAPIModule = (LPGETMAPIMODULE) GetProcAddress(GetModuleHandle(NULL),szGetMAPIModule);
				if (pfnGetMAPIModule)
				{
					HMODULE hMAPI = NULL;
					pfnGetMAPIModule(&hMAPI,true);
					if (pfnSimpleDialog) pfnSimpleDialog(g_szAddInName,L"MAPI loaded at 0x%08X",hMAPI);
				}
				break;
			}
		case 1 : 
			{
				if (pfnSimpleDialog) pfnSimpleDialog(g_szAddInName,L"Checking MAPI load status");
				LPGETMAPIMODULE pfnGetMAPIModule = (LPGETMAPIMODULE) GetProcAddress(GetModuleHandle(NULL),szGetMAPIModule);
				if (pfnGetMAPIModule)
				{
					HMODULE hMAPI = NULL;
					pfnGetMAPIModule(&hMAPI,false);
					if (pfnSimpleDialog) pfnSimpleDialog(g_szAddInName,L"MAPI loaded at 0x%08X",hMAPI);
				}
				break;
			}
		case 2:
			{
				TestComplexDialog();
				break;
			}
		default:
			{
				DisplayAddInMenuParams(lpParams);
				break;
			}
		}
	}

	AddInLog(true,L"CallMenu: Done - returning hRes = 0x%08X\n",hRes);
	return hRes;
}

NAME_ARRAY_ENTRY g_PropTagArray[] = 
{
	{0x12340102,	L"1234Prop" },
	{0x00010001,	L"aaaProp" },
	{0x00020042,	L"bbbProp" },
	{0x00010003,	L"aPR_ACKNOWLEDGEMENT_MODE" },
	{0x00010003,	L"cPR_ACKNOWLEDGEMENT_MODE" },
	{0x00010003,	L"PR_ACKNOWLEDGEMENT_MODE" },
	{0x00010003,	L"dPR_ACKNOWLEDGEMENT_MODE" },
	{0x00010003,	L"bPR_ACKNOWLEDGEMENT_MODE" },
	{0xffff0069,	L"xxxProp" },
};
// GetPropTags - returns static array of property names
void STDMETHODCALLTYPE GetPropTags(ULONG* lpulPropTags, LPNAME_ARRAY_ENTRY* lppPropTags)
{
	if (!lppPropTags || !lpulPropTags) return;
	*lpulPropTags = sizeof(g_PropTagArray)/sizeof(NAME_ARRAY_ENTRY);
	*lppPropTags = g_PropTagArray;
}

NAME_ARRAY_ENTRY g_PropTypeArray[] = 
{
	{0x0075,	L"PT_ME_TOO" }, // a new prop type
	{0x0102,	L"PT_BINARY-NewName" }, // test duplicates of real prop types
	{0x0075,	L"aPT_ME_TOO" }, // test sort
	{0x0042,	L"PT_I_ROCK" }, // another new prop type
	{0x0075,	L"PT_ME_TOO" }, // test duplicates
};

// GetPropTypes - returns static array of property types
void STDMETHODCALLTYPE GetPropTypes(ULONG* lpulPropTypes, LPNAME_ARRAY_ENTRY* lppPropTypes)
{
	if (!lppPropTypes || !lpulPropTypes) return;
	*lpulPropTypes = sizeof(g_PropTypeArray)/sizeof(NAME_ARRAY_ENTRY);
	*lppPropTypes = g_PropTypeArray;
}

DEFINE_GUID(IID_IThisIsNotARealGUID,
			0x12345678,
			0x1234, 0x4321, 0x42, 0x86, 0x75, 0x30, 0x98, 0x67, 0x53, 0x09);
DEFINE_GUID(IID_IAttachmentSecurity,
			0xB2533636,
			0xC3F3, 0x416f, 0xBF, 0x04, 0xAE, 0xFE, 0x41, 0xAB, 0xAA, 0xE2);

GUID_ARRAY_ENTRY g_PropGuidArray[] = 
{
	&IID_IThisIsNotARealGUID, L"IID_IThisIsNotARealGUID",
	&IID_IAttachmentSecurity, L"IID_IAttachmentSecurity",
	&IID_IAttachmentSecurity, L"IID_IAttachmentSecurityWithANewName",
};

// GetPropGuids - returns static array of property guids
void STDMETHODCALLTYPE GetPropGuids(ULONG* lpulPropGuids, LPGUID_ARRAY_ENTRY* lppPropGuids)
{
	if (!lppPropGuids || !lpulPropGuids) return;
	*lpulPropGuids = sizeof(g_PropGuidArray)/sizeof(GUID_ARRAY_ENTRY);
	*lppPropGuids = g_PropGuidArray;
}
DEFINE_OLEGUID(PSETID_Address, MAKELONG(0x2000+(0x04),0x0006),0,0);
DEFINE_OLEGUID(PSETID_Common, MAKELONG(0x2000+(8),0x0006),0,0);

NAMEID_ARRAY_ENTRY g_NameIDArray[] = 
{
	{0x8f42, &IID_IThisIsNotARealGUID, L"dispidFake1"},
	{0x8f44, &IID_IThisIsNotARealGUID, L"dispidFake3"},
	{0x8f43, &IID_IThisIsNotARealGUID, L"dispidFake2"},
	{0x8047, &PSETID_Address, L"dispidWorkAddressState"},
	{0x8047, &PSETID_Common, L"dispidWorkAddressState"},
	{0x8045, &PSETID_Address, L"dispidWorkAddressStreet"},
	{0x8046, &PSETID_Address, L"dispidWorkAddressCity"},
	{0x8047, &PSETID_Address, L"dispidWorkAddressState"},
	{0x8048, &PSETID_Address, L"dispidWorkAddressPostalCode"},
	{0x8048, &PSETID_Address, L"dispidWorkAddressPostalCode"},
	{0x8048, 0, L"dispidWorkAddressPostalCodeNULL"},
	{0x8049, &PSETID_Address, L"dispidWorkAddressCountry"},
	{0x8047, &PSETID_Address, L"FakedispidWorkAddressState"},
	{0x8f45, &IID_IThisIsNotARealGUID, L"dispidFake4"},
};

// GetNameIDs - returns static array of named prop mappings
void STDMETHODCALLTYPE GetNameIDs(ULONG* lpulNameIDs, LPNAMEID_ARRAY_ENTRY* lppNameIDs)
{
	if (!lppNameIDs || !lpulNameIDs) return;
	*lpulNameIDs = sizeof(g_NameIDArray)/sizeof(NAMEID_ARRAY_ENTRY);
	*lppNameIDs = g_NameIDArray;
}

//when listing flagVALUE entries, NULL values need to come first
FLAG_ARRAY_ENTRY g_FlagArray[] = 
{
	FLAG_ENTRY(PR_ACCESS,MAPI_ACCESS_MODIFY,flagFLAG)
	FLAG_ENTRY(PR_ACCESS,MAPI_ACCESS_READ,flagFLAG)
	FLAG_ENTRY(PR_ACCESS,MAPI_ACCESS_DELETE,flagFLAG)
	FLAG_ENTRY(PR_ACCESS,MAPI_ACCESS_CREATE_HIERARCHY,flagFLAG)
	FLAG_ENTRY(PR_ACCESS,MAPI_ACCESS_CREATE_CONTENTS,flagFLAG)
	FLAG_ENTRY(PR_ACCESS,MAPI_ACCESS_CREATE_ASSOCIATED,flagFLAG)
	FLAG_ENTRY(PR_ACCESS,33,flagFLAG)

	FLAG_ENTRY(PR_ACCESS_LEVEL,MAPI_MODIFY,flagFLAG)

	FLAG_ENTRY(PR_ANTIVIRUS_SCAN_INFO,ANTIVIRUS_SCAN_NO_VIRUS,flagVALUE)//NULL value
	FLAG_ENTRY(PR_ANTIVIRUS_SCAN_INFO,ANTIVIRUS_SCAN_VIRUS_PRESENT,flagFLAG)
	FLAG_ENTRY(PR_ANTIVIRUS_SCAN_INFO,ANTIVIRUS_SCAN_VIRUS_CLEANED,flagFLAG)
	FLAG_ENTRY(PR_ANTIVIRUS_SCAN_INFO,ANTIVIRUS_SCAN_VIRUS_DELETED,flagFLAG)

	FLAG_ENTRY(PR_ACCESS,MAPI_ACCESS_MODIFY,flagFLAG)
	FLAG_ENTRY(PR_ACCESS,MAPI_ACCESS_READ,flagFLAG)
	FLAG_ENTRY(PR_ACCESS,MAPI_ACCESS_DELETE,flagFLAG)
	FLAG_ENTRY(PR_ACCESS,MAPI_ACCESS_CREATE_HIERARCHY,flagFLAG)
	FLAG_ENTRY(PR_ACCESS,MAPI_ACCESS_CREATE_CONTENTS,flagFLAG)
	FLAG_ENTRY(PR_ACCESS,MAPI_ACCESS_CREATE_ASSOCIATED,flagFLAG)

	FLAG_ENTRY(PR_ANTIVIRUS_SCAN_INFO,ANTIVIRUS_SCAN_NO_VIRUS,flagVALUE)//NULL value
	FLAG_ENTRY(PR_ANTIVIRUS_SCAN_INFO,ANTIVIRUS_SCAN_VIRUS_PRESENT,flagFLAG)
	FLAG_ENTRY(PR_ANTIVIRUS_SCAN_INFO,ANTIVIRUS_SCAN_VIRUS_CLEANED,flagFLAG)
	FLAG_ENTRY(PR_ANTIVIRUS_SCAN_INFO,ANTIVIRUS_SCAN_VIRUS_DELETED,flagFLAG)

	//check and clear flags first, then look at values which remain
	FLAG_ENTRY(PR_RECIPIENT_TYPE,MAPI_P1,flagFLAG)
	FLAG_ENTRY(PR_RECIPIENT_TYPE,MAPI_SUBMITTED,flagFLAG)
	//This entry clears any high level bits so we can look at the low order as a value
	CLEAR_BITS_ENTRY(PR_RECIPIENT_TYPE,0xffff0000)
	FLAG_ENTRY(PR_RECIPIENT_TYPE,MAPI_ORIG,flagVALUE)//NULL value
	FLAG_ENTRY(PR_RECIPIENT_TYPE,MAPI_TO,flagVALUE)
	FLAG_ENTRY(PR_RECIPIENT_TYPE,MAPI_CC,flagVALUE)
	FLAG_ENTRY(PR_RECIPIENT_TYPE,MAPI_BCC,flagVALUE)
	FLAG_ENTRY(PR_RECIPIENT_TYPE,MAPI_P1,flagVALUE)
};

// GetPropFlags - returns static array of property flags
void STDMETHODCALLTYPE GetPropFlags(ULONG* lpulPropFlags, LPFLAG_ARRAY_ENTRY* lppPropFlags)
{
	if (!lppPropFlags || !lpulPropFlags) return;
	*lpulPropFlags = sizeof(g_FlagArray)/sizeof(FLAG_ARRAY_ENTRY);
	*lppPropFlags = g_FlagArray;
}
