#pragma once

#include <mapix.h>
#include <mapispi.h>
#include <mapiutil.h>
#include <mapiform.h>
#include <stdio.h>
#include <tchar.h>
#include <strsafe.h>
#include <imessage.h>
#include "edkmdb.h"
#include "MFCMAPI.h"
#include "Appointments.h"
#include "Contacts.h"
#include "Tasks.h"
#include "Mails.h"

DWORD SystemTimeToRTime(LPSYSTEMTIME lpSystemTime);
HRESULT BuildConversationIndex(ULONG* lpcbConversationIndex,
							   LPBYTE* lppConversationIndex);

#define PR_ICON_INDEX PROP_TAG(PT_LONG, 0x1080)

enum IdGroup
{
	IDC_RCEV_PAT_ORB_DAILY = 0x200A,
	IDC_RCEV_PAT_ORB_WEEKLY,
	IDC_RCEV_PAT_ORB_MONTHLY,
	IDC_RCEV_PAT_ORB_YEARLY,
	IDC_RCEV_PAT_ERB_END=0x2021,
	IDC_RCEV_PAT_ERB_AFTERNOCCUR,
	IDC_RCEV_PAT_ERB_NOEND,
};
enum
{
	rptMinute = 0,
	rptWeek,
	rptMonth,
	rptMonthNth,
	rptMonthEnd,
	rptHjMonth = 10,
	rptHjMonthNth,
	rptHjMonthEnd
};
#define CAL_DEFAULT 0
const ULONG rdfSun = 0x01;
const ULONG rdfMon = 0x02;
const ULONG rdfTue = 0x04;
const ULONG rdfWed = 0x08;
const ULONG rdfThu = 0x10;
const ULONG rdfFri = 0x20;
const ULONG rdfSat = 0x40;
