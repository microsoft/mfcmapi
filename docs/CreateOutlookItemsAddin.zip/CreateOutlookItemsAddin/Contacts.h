#pragma once

void DisplayAddContactDialog(LPMAPIFOLDER lpFolder);