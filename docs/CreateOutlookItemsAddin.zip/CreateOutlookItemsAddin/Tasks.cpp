#include "CreateOutlookItemsAddin.h"
#include <initguid.h>

DEFINE_OLEGUID(PSETID_Task,   MAKELONG(0x2000+(0x3),0x0006),0,0);
DEFINE_OLEGUID(PSETID_Common, MAKELONG(0x2000+(0x8),0x0006),0,0);

enum TaskDelegMsgType {tdmtNothing = 0,	// The task object is not assigned.
					   tdmtTaskReq,		// The task object is embedded in a task request.
					   tdmtTaskAcc,		// The task object has been accepted by the task assignee.
					   tdmtTaskDec,		// The task object was rejected by the task assignee.
					   tdmtTaskUpd,		// The task object is embedded in a task update.
					   tdmtTaskSELF};	// The task object was assigned to the task assigner (self-delegation).
enum TaskStatusValue {
	tsvNotStarted = 0, // The user has not started work on the task object. If this value is set,
                       // dispidPercentComplete MUST be 0.0.
	tsvInProgress,     // The user�s work on this task object is in progress. If this value is set,
                       // dispidPercentComplete MUST be greater than 0.0 and less than 1.0
	tsvComplete,       // The user�s work on this task object is complete. If this value is set,
                       // dispidPercentComplete MUST be 1.0, dispidTaskDateCompleted
					   // MUST be the current date, and dispidTaskComplete MUST be true.
	tsvWaiting,        // The user is waiting on somebody else.
	tsvDeferred};      // The user has deferred work on the task object.
enum TaskDelegState {
	tdsNOM = 0,	// This task object was created to correspond to a task object that was
                // embedded in a task rejection but could not be found locally.
	tdsOWNNEW,  // The task object is not assigned.
	tdsOWN,     // The task object is the task assignee�s copy of an assigned task object.
	tdsACC,	    // The task object is the task assigner�s copy of an assigned task object.
	tdsDEC};    // The task object is the task assigner�s copy of a rejected task object.
enum TaskOwnershipValue {
	tovNew,   // The task object is not assigned.
	tovDeleg, // The task object is the task assigner�s copy of the task object.
	tovMe};   // The task object is the task assignee�s copy of the task object.
enum TaskDelegValue {
	tdvNone,      // The task object is not assigned.
	tdvUnknown,   // The task object�s acceptance status is unknown.
	tdvAccepted,  // The task assignee has accepted the task object. This value is set when
                  // the client processes a task acceptance.
	tdvDeclined}; // The task assignee has rejected the task object. This value is set when the
                  // client processes a task rejection.

#define PidLidTaskMode 0x8518
#define PidLidTaskStatus 0x8101
#define PidLidPercentComplete 0x8102
#define PidLidCommonStart 0x8516
#define PidLidTaskStartDate 0x8104
#define PidLidCommonEnd 0x8517
#define PidLidTaskDueDate 0x8105
#define PidLidTaskState 0x8113
#define PidLidTaskRecurrence 0x8116
#define PidLidTaskDeadOccurrence 0x8109
#define PidLidTaskOwner 0x811F
#define PidLidTaskFRecurring 0x8126
#define PidLidTaskOwnership 0x8129
#define PidLidTaskAcceptanceState 0x812A
#define PidLidTaskFFixOffline 0x812C
#define PidLidTaskComplete 0x811C

// Allocates with new, free with delete
// The following code builds binary recurrence data for a weekly task
// It assumes, but does not check, that the start and end and FirstDOW dates are consistent with the period, occurrence count, and pattern type specific
HRESULT BuildWeeklyTaskRecurrencePattern(
	SYSTEMTIME* lpstStart,
	SYSTEMTIME* lpstEnd,
	SYSTEMTIME* lpstFirstDOW,
	DWORD dwPeriod,
	DWORD dwOccurrenceCount,
	DWORD dwPatternTypeSpecific,
	ULONG* lpcbRecur,
	LPBYTE* lppRecur)
{
	if (!lpcbRecur || !lppRecur || !lpstStart || !lpstEnd || !lpstFirstDOW) return MAPI_E_INVALID_PARAMETER;

	// Calculate how large our weekly task recurrence pattern will be
	size_t cbRecur = sizeof(WORD)*5 + // ReaderVersion, WriterVersion, RecurFrequency, PatternType, CalendarType
		sizeof(DWORD)*3 + // FirstDateTime, Period, SlidingFlag
		sizeof(DWORD) + // PatternTypeSpecific
		sizeof(DWORD)*7; // EndType, OccurrenceCount, FirstDOW, DeletedInstanceCount(0), ModifiedInstanceCount(0), StartDate, EndDate

	// Allocate our buffer
	LPBYTE lpRecur = new BYTE[cbRecur];

	// Populate it
	if (lpRecur)
	{
		memset(lpRecur,0,cbRecur);

		LPBYTE pb = lpRecur;
		*(WORD*)pb = 0x3004; // ReaderVersion
		pb += sizeof(WORD);
		*(WORD*)pb = 0x3004; // WriterVersion
		pb += sizeof(WORD);
		*(WORD*)pb = IDC_RCEV_PAT_ORB_WEEKLY; // RecurFrequency - The pattern of the recurrence is weekly.
		pb += sizeof(WORD);
		*(WORD*)pb = rptWeek; // PatternType - The pattern type is Week
		pb += sizeof(WORD);
		*(WORD*)pb = CAL_DEFAULT; // CalendarType - The calendar type is Gregorian
		pb += sizeof(WORD);
		*(DWORD*)pb = SystemTimeToRTime(lpstFirstDOW) % (10080*dwPeriod); // FirstDateTime
		pb += sizeof(DWORD);
		*(DWORD*)pb = dwPeriod; // Period
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0x00000000; // SlidingFlag - The recurring instances do not rely on completion of the previous Instances.
		pb += sizeof(DWORD);
		*(DWORD*)pb = dwPatternTypeSpecific; // PatternTypeSpecific
		pb += sizeof(DWORD);
		*(DWORD*)pb = IDC_RCEV_PAT_ERB_AFTERNOCCUR; // EndType - End after N occurrences.
		pb += sizeof(DWORD);
		*(DWORD*)pb = dwOccurrenceCount; // OccurrenceCount
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0x00000000; // FirstDOW - The first day of the week on the calendar is Sunday
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0x00000000; // DeletedInstanceCount - There are no deleted Instances.
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0x00000000; // ModifiedInstanceCount - There are no modified Instances.
		pb += sizeof(DWORD);
		*(DWORD*)pb = SystemTimeToRTime(lpstStart); // StartDate
		pb += sizeof(DWORD);
		*(DWORD*)pb = SystemTimeToRTime(lpstEnd); // EndDate
		pb += sizeof(DWORD);

		// Return it
		*lpcbRecur = cbRecur;
		*lppRecur = (LPBYTE) lpRecur;
		return S_OK;
	}

	return MAPI_E_CALL_FAILED;
}

// The array is the list of named properties to be set.
ULONG aulTaskProps[] = {
	PidLidTaskMode,
	PidLidCommonEnd,
	PidLidTaskStatus,
	PidLidPercentComplete,
	PidLidTaskState,
	PidLidTaskRecurrence,
	PidLidTaskDeadOccurrence,
	PidLidTaskOwner,
	PidLidTaskFRecurring,
	PidLidTaskOwnership,
	PidLidTaskAcceptanceState,
	PidLidTaskFFixOffline,
	PidLidTaskDueDate,
	PidLidTaskComplete,
};
#define ulTaskProps (sizeof(aulTaskProps)/sizeof(aulTaskProps [0]))

// The enum is to aid in building the property values for SetProps.
// The beginning of the list must match aulTaskProps. All non-named properties must come at the end.
enum {
	// PSETID_Common
	p_PidLidTaskMode,
	p_PidLidCommonEnd,
	// PSETID_Task - do not reorder without updating ulFirstTaskProp
	p_PidLidTaskStatus,
	p_PidLidPercentComplete,
	p_PidLidTaskState,
	p_PidLidTaskRecurrence,
	p_PidLidTaskDeadOccurrence,
	p_PidLidTaskOwner,
	p_PidLidTaskFRecurring,
	p_PidLidTaskOwnership,
	p_PidLidTaskAcceptanceState,
	p_PidLidTaskFFixOffline,
	p_PidLidTaskDueDate,
	p_PidLidTaskComplete,
	// Non named properties
	p_PR_MESSAGE_CLASS_W,
	p_PR_ICON_INDEX,
	p_PR_SUBJECT_W,
	p_PR_MESSAGE_FLAGS,
	p_PR_BODY_W,
	NUM_PROPS};

ULONG ulFirstTaskProp = p_PidLidTaskStatus;

HRESULT AddTask(LPMAPIFOLDER lpFolder,
				SYSTEMTIME* lpstStart, // PidLidCommonEnd, PidLidTaskDueDate, PidLidTaskRecurrence
				SYSTEMTIME* lpstEnd, // PidLidTaskRecurrence
				SYSTEMTIME* lpstFirstDOW, // PidLidTaskRecurrence
				DWORD dwPeriod, // PidLidTaskRecurrence
				DWORD dwOccurrenceCount, // PidLidTaskRecurrence
				DWORD dwPatternTypeSpecific, // PidLidTaskRecurrence
				LPWSTR szSubject, // PR_SUBJECT_W
				LPWSTR szBody) // PR_BODY_W
{
	if (!lpFolder) return MAPI_E_INVALID_PARAMETER;

	HRESULT hRes = S_OK;
	LPMESSAGE lpMessage = 0;
	// create a message and set its properties
	hRes = lpFolder->CreateMessage(0,
		0,
		&lpMessage);
	if (SUCCEEDED(hRes))
	{
		MAPINAMEID  rgnmid[ulTaskProps];
		LPMAPINAMEID rgpnmid[ulTaskProps];
		LPSPropTagArray lpNamedPropTags = NULL;

		ULONG i = 0;
		for (i = 0 ; i < ulTaskProps ; i++)
		{
			if (i < ulFirstTaskProp)
				rgnmid[i].lpguid = (LPGUID)&PSETID_Common;
			else
				rgnmid[i].lpguid = (LPGUID)&PSETID_Task;
			rgnmid[i].ulKind = MNID_ID;
			rgnmid[i].Kind.lID = aulTaskProps[i];
			rgpnmid[i] = &rgnmid[i];
		}

		hRes = lpFolder->GetIDsFromNames(
			ulTaskProps,
			(LPMAPINAMEID*) &rgpnmid,
			NULL,
			&lpNamedPropTags);
		if (SUCCEEDED(hRes) && lpNamedPropTags)
		{
			// Since we know in advance which props we'll be setting, we can statically declare most of the structures involved and save expensive MAPIAllocateBuffer calls
			SPropValue spvProps[NUM_PROPS] = {0};
			spvProps[p_PidLidTaskMode].ulPropTag            = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTaskMode],PT_LONG);
			spvProps[p_PidLidCommonEnd].ulPropTag           = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidCommonEnd],PT_SYSTIME);

			spvProps[p_PidLidTaskStatus].ulPropTag          = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTaskStatus],PT_LONG);
			spvProps[p_PidLidPercentComplete].ulPropTag     = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidPercentComplete],PT_DOUBLE);
			spvProps[p_PidLidTaskState].ulPropTag           = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTaskState],PT_LONG);
			spvProps[p_PidLidTaskRecurrence].ulPropTag      = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTaskRecurrence],PT_BINARY);
			spvProps[p_PidLidTaskDeadOccurrence].ulPropTag  = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTaskDeadOccurrence],PT_BOOLEAN);
			spvProps[p_PidLidTaskOwner].ulPropTag           = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTaskOwner],PT_UNICODE);
			spvProps[p_PidLidTaskFRecurring].ulPropTag      = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTaskFRecurring],PT_BOOLEAN);
			spvProps[p_PidLidTaskOwnership].ulPropTag       = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTaskOwnership],PT_LONG);
			spvProps[p_PidLidTaskAcceptanceState].ulPropTag = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTaskAcceptanceState],PT_LONG);
			spvProps[p_PidLidTaskFFixOffline].ulPropTag     = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTaskFFixOffline],PT_BOOLEAN);
			spvProps[p_PidLidTaskDueDate].ulPropTag         = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTaskDueDate],PT_SYSTIME);
			spvProps[p_PidLidTaskComplete].ulPropTag        = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTaskComplete],PT_SYSTIME);

			spvProps[p_PR_MESSAGE_CLASS_W].ulPropTag  = PR_MESSAGE_CLASS_W;
			spvProps[p_PR_ICON_INDEX].ulPropTag       = PR_ICON_INDEX;
			spvProps[p_PR_SUBJECT_W].ulPropTag        = PR_SUBJECT_W;
			spvProps[p_PR_MESSAGE_FLAGS].ulPropTag    = PR_MESSAGE_FLAGS;
			spvProps[p_PR_BODY_W].ulPropTag           = PR_BODY_W;

			spvProps[p_PidLidTaskMode].Value.l = tdmtNothing;
			SYSTEMTIME stStartUTC = {0};
			TzSpecificLocalTimeToSystemTime(NULL,lpstStart,&stStartUTC);
			SystemTimeToFileTime(&stStartUTC,&spvProps[p_PidLidCommonEnd].Value.ft);

			spvProps[p_PidLidTaskStatus].Value.l = tsvNotStarted;
			spvProps[p_PidLidPercentComplete].Value.dbl = 0.0;
			spvProps[p_PidLidTaskState].Value.l = tdsOWNNEW;
			spvProps[p_PidLidTaskDeadOccurrence].Value.b = false;
			spvProps[p_PidLidTaskOwner].Value.lpszW = L"Unknown";
			spvProps[p_PidLidTaskFRecurring].Value.b = true;
			spvProps[p_PidLidTaskOwnership].Value.l = tovNew;
			spvProps[p_PidLidTaskAcceptanceState].Value.l = tdvNone;
			spvProps[p_PidLidTaskFFixOffline].Value.b = true;
			SystemTimeToFileTime(lpstStart,&spvProps[p_PidLidTaskDueDate].Value.ft);
			spvProps[p_PidLidTaskComplete].Value.b = false;

			spvProps[p_PR_MESSAGE_CLASS_W].Value.lpszW = L"IPM.Task";
			spvProps[p_PR_ICON_INDEX].Value.l = 0x501; // Unassigned Recurring Task
			spvProps[p_PR_SUBJECT_W].Value.lpszW = szSubject;
			spvProps[p_PR_MESSAGE_FLAGS].Value.l = MSGFLAG_READ;
			spvProps[p_PR_BODY_W].Value.lpszW = szBody;

			hRes = BuildWeeklyTaskRecurrencePattern(
				lpstStart,
				lpstEnd,
				lpstFirstDOW,
				dwPeriod,
				dwOccurrenceCount,
				dwPatternTypeSpecific,
				&spvProps[p_PidLidTaskRecurrence].Value.bin.cb,
				&spvProps[p_PidLidTaskRecurrence].Value.bin.lpb);
			if (SUCCEEDED(hRes))
			{
				hRes = lpMessage->SetProps(NUM_PROPS, spvProps, NULL);
				if (SUCCEEDED(hRes))
				{
					hRes = lpMessage->SaveChanges(FORCE_SAVE);
				}
			}
			if (spvProps[p_PidLidTaskRecurrence].Value.bin.lpb)
				delete[] spvProps[p_PidLidTaskRecurrence].Value.bin.lpb;
		}
		MAPIFreeBuffer(lpNamedPropTags);
	}
	if (lpMessage) lpMessage->Release();
	return hRes;
}

_AddInDialogControl g_TaskControls[] =
{
	// {type,readonly,multiline,defaultcheckstate,defaultvalue(number),text label,defaultvalue(text),cbBin,lpBin}
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Subject", L"This is a sample task",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Body", L"This is the body of a sample task",0,0},
};
void DisplayAddTaskDialog(LPMAPIFOLDER lpFolder)
{
	LPCOMPLEXDIALOG pfnComplexDialog = (LPCOMPLEXDIALOG) GetProcAddress(GetModuleHandle(NULL),szComplexDialog);
	LPFREEDIALOGRESULT pfnFreeDialogResult = (LPFREEDIALOGRESULT) GetProcAddress(GetModuleHandle(NULL),szFreeDialogResult);
	if (pfnComplexDialog && pfnFreeDialogResult)
	{
		_AddInDialog myDialog = {0};
		myDialog.szTitle = L"Add Task";
		myDialog.szPrompt = L"Thus function creates a recurring task in the current folder\r\n"
			L"\twith the following recurrence pattern:\r\n"
			L"Type: Weekly, every Friday for 2 weeks\r\n"
			L"Date: January 9th, 2009 to January 16th, 2009\r\n"
			L"\r\n"
			L"Fill out the subject and body of your task.";
		myDialog.ulButtonFlags = CEDITOR_BUTTON_OK;
		myDialog.ulNumControls = sizeof(g_TaskControls)/sizeof(_AddInDialogControl);
		myDialog.lpDialogControls = g_TaskControls;

		LPADDINDIALOGRESULT lpDialogResult = NULL;

		pfnComplexDialog(&myDialog,&lpDialogResult);
		if (lpDialogResult)
		{
			ULONG i = 0;
			LPWSTR szSubject = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szBody = lpDialogResult->lpDialogControlResults[i++].szText;

			// In non-sample code, stEnd and stFirstDOW would be computed from the start date and recurrence pattern
			// We'll hard code here them since we're not even allowing the user to input the date or pattern

			// Start date
			SYSTEMTIME stStart = {0};
			stStart.wYear = 2009;
			stStart.wMonth = 1;
			stStart.wDay = 9;

			// End date, given the period, occurrence count, and pattern type
			SYSTEMTIME stEnd = {0};
			stEnd.wYear = 2009;
			stEnd.wMonth = 1;
			stEnd.wDay = 16;

			// We're hard coding Sunday as our FirstDOW, so this is the first DOW before the start date
			SYSTEMTIME stFirstDOW = {0};
			stFirstDOW.wYear = 2009;
			stFirstDOW.wMonth = 1;
			stFirstDOW.wDay = 4;

			DWORD dwPeriod = 1; // Every 1 week
			DWORD dwOccurrenceCount = 2; // 2 occurrences
			DWORD dwPatternTypeSpecific = rdfFri; // On Fridays

			(void) AddTask(lpFolder,
				&stStart,
				&stEnd,
				&stFirstDOW,
				dwPeriod,
				dwOccurrenceCount,
				dwPatternTypeSpecific,
				szSubject,
				szBody);
		}
		pfnFreeDialogResult(lpDialogResult);
	}
}
