#include "CreateOutlookItemsAddin.h"
#include <initguid.h>

DEFINE_OLEGUID(PSETID_Address, MAKELONG(0x2000+(0x04),0x0006),0,0);

#define PidLidFileUnderList                0x8026
#define PidLidAutoLog                      0x8025
#define PidLidAddressBookProviderEmailList 0x8028
#define PidLidAddressBookProviderArrayType 0x8029
#define PidLidFileUnder                    0x8005
#define PidLidFileUnderId                  0x8006
#define PidLidContactCharSet               0x8023
#define PidLidEmail1DisplayName            0x8080
#define PidLidEmail1AddressType            0x8082
#define PidLidEmail1EmailAddress           0x8083
#define PidLidEmail1OriginalDisplayName    0x8084
#define PidLidEmail1OriginalEntryID        0x8085
#define PidLidWorkAddressStreet            0x8045
#define PidLidWorkAddressCity              0x8046
#define PidLidWorkAddressState             0x8047
#define PidLidWorkAddressPostalCode        0x8048
#define PidLidWorkAddressCountry           0x8049
#define PidLidWorkAddressCountryCode       0x80DB
#define PidLidPostalAddressId              0x8022
#define PidLidAddressCountryCode           0x80DD
#define PidLidContactItemData              0x8007
#define PidLidHtml                         0x802B

#pragma warning (disable: 4200)
typedef struct _OneOffEntryID {
	ULONG	ulFlags;
	MAPIUID muid;
	ULONG   ulBitMask; // Protocol doc shows Version and the bitmasks as taking 4 bytes together. Merging them in the struct allows MAPI_UNICODE to line up neatly
	BYTE    bData[];
} ONEOFFENTRYID;
#pragma warning (default: 4200)
typedef UNALIGNED ONEOFFENTRYID *LPONEOFFENTRYID;

const MAPIUID muidOneOffEntryID = {0x81, 0x2b, 0x1f, 0xa4, 0xbe, 0xa3, 0x10, 0x19, 0x9d, 0x6e, 0x00, 0xdd, 0x01, 0x0f, 0x54, 0x02};

#define ENCODING_PREFERENCE			((ULONG) 0x00020000)
#define ENCODING_MIME				((ULONG) 0x00040000)
#define BODY_ENCODING_HTML			((ULONG) 0x00080000)
#define BODY_ENCODING_TEXT_AND_HTML	((ULONG) 0x00100000)
#define OOP_DONT_LOOKUP             ((ULONG) 0x10000000)

// Allocates with new, free with delete
HRESULT BuildOneOff(
					LPWSTR szDisplayName,
					LPWSTR szAddressType, // Note that this must be UPPERCASE
					LPWSTR szEmailAddress,
					ULONG* lpcbEID,
					LPBYTE* lppEID)
{
	if (!szDisplayName || !szAddressType || !szEmailAddress || !lpcbEID || !lppEID) return MAPI_E_INVALID_PARAMETER;

	// Calculate how large our EID will be
	size_t cbEID = sizeof(ONEOFFENTRYID); // fixed length of our structure
	size_t cbDisplayName = 0;
	size_t cbAddressType = 0;
	size_t cbEmailAddress = 0;
	(void) StringCbLengthW(szDisplayName,STRSAFE_MAX_CCH*sizeof(WCHAR),&cbDisplayName);
	(void) StringCbLengthW(szAddressType,STRSAFE_MAX_CCH*sizeof(WCHAR),&cbAddressType);
	(void) StringCbLengthW(szEmailAddress,STRSAFE_MAX_CCH*sizeof(WCHAR),&cbEmailAddress);

	// Increment our cb to include the NULL terminators
	cbDisplayName += sizeof(WCHAR);
	cbAddressType += sizeof(WCHAR);
	cbEmailAddress += sizeof(WCHAR);
	cbEID += cbDisplayName+cbAddressType+cbEmailAddress;

	// Allocate our buffer
	LPONEOFFENTRYID lpEID = (LPONEOFFENTRYID) new BYTE[cbEID];

	// Populate it
	if (lpEID)
	{
		memset(lpEID,0,cbEID);
		lpEID->muid = muidOneOffEntryID;
		lpEID->ulBitMask |= MAPI_UNICODE; // Set U, the unicode bit
		lpEID->ulBitMask |= OOP_DONT_LOOKUP; // Set L, the no lookup bit
		lpEID->ulBitMask |= MAPI_SEND_NO_RICH_INFO; // Set M, the mime bit
		lpEID->ulBitMask |= ENCODING_PREFERENCE|ENCODING_MIME|BODY_ENCODING_TEXT_AND_HTML; // Set the encoding format

		LPBYTE pb = lpEID->bData;
		// this will copy the string and the NULL terminator together
		memcpy(pb,szDisplayName,cbDisplayName);
		pb += cbDisplayName;
		memcpy(pb,szAddressType,cbAddressType);
		pb += cbAddressType;
		memcpy(pb,szEmailAddress,cbEmailAddress);
		pb += cbEmailAddress;

		// Return it
		*lpcbEID = cbEID;
		*lppEID = (LPBYTE) lpEID;
		return S_OK;
	}

	return MAPI_E_CALL_FAILED;
}

// The array is the list of named properties to be set.
ULONG aulContactProps[] = {
	PidLidFileUnderList,
	PidLidAutoLog,
	PidLidAddressBookProviderEmailList,
	PidLidAddressBookProviderArrayType,
	PidLidFileUnder,
	PidLidFileUnderId,
	PidLidContactCharSet,
	PidLidEmail1DisplayName,
	PidLidEmail1AddressType,
	PidLidEmail1EmailAddress,
	PidLidEmail1OriginalDisplayName,
	PidLidEmail1OriginalEntryID,
	PidLidWorkAddressStreet,
	PidLidWorkAddressCity,
	PidLidWorkAddressState,
	PidLidWorkAddressPostalCode,
	PidLidWorkAddressCountry,
	PidLidWorkAddressCountryCode,
	PidLidPostalAddressId,
	PidLidAddressCountryCode,
	PidLidContactItemData,
	PidLidHtml,
};
#define ulContactProps (sizeof(aulContactProps)/sizeof(aulContactProps [0]))

// The enum is to aid in building the property values for SetProps.
// The beginning of the list must match aulContactProps. All non-named properties must come at the end.
enum {
	p_PidLidFileUnderList,
	p_PidLidAutoLog,
	p_PidLidAddressBookProviderEmailList,
	p_PidLidAddressBookProviderArrayType,
	p_PidLidFileUnder,
	p_PidLidFileUnderId,
	p_PidLidContactCharSet,
	p_PidLidEmail1DisplayName,
	p_PidLidEmail1AddressType,
	p_PidLidEmail1EmailAddress,
	p_PidLidEmail1OriginalDisplayName,
	p_PidLidEmail1OriginalEntryID,
	p_PidLidWorkAddressStreet,
	p_PidLidWorkAddressCity,
	p_PidLidWorkAddressState,
	p_PidLidWorkAddressPostalCode,
	p_PidLidWorkAddressCountry,
	p_PidLidWorkAddressCountryCode,
	p_PidLidPostalAddressId,
	p_PidLidAddressCountryCode,
	p_PidLidContactItemData,
	p_PidLidHtml,
	p_PR_DISPLAY_NAME_PREFIX_W,
	p_PR_SURNAME_W,
	p_PR_MIDDLE_NAME_W,
	p_PR_GIVEN_NAME_W,
	p_PR_GENERATION_W,
	p_PR_INITIALS_W,
	p_PR_COMPANY_NAME_W,
	p_PR_BUSINESS_HOME_PAGE_W,
	p_PR_BUSINESS_TELEPHONE_NUMBER_W,
	p_PR_STREET_ADDRESS_W,
	p_PR_LOCALITY_W,
	p_PR_STATE_OR_PROVINCE_W,
	p_PR_POSTAL_CODE_W,
	p_PR_COUNTRY_W,
	p_PR_DISPLAY_NAME_W,
	p_PR_MESSAGE_CLASS_W,
	p_PR_ICON_INDEX,
	p_PR_SUBJECT_PREFIX_W,
	p_PR_SUBJECT_W,
	p_PR_BODY_W,
	NUM_PROPS};

HRESULT AddContact(LPMAPIFOLDER lpFolder,
			LPWSTR szFullName, // PR_DISPLAY_NAME_W, PR_SUBJECT_W
			LPWSTR szGivenName, // PR_GIVEN_NAME_W
			LPWSTR szMiddleName, // PR_MIDDLE_NAME_W
			LPWSTR szSurName, // PR_SURNAME_W
			LPWSTR szInitials, // PR_INITIALS_W
			LPWSTR szFileUnder, // PidLidFileUnder
			LPWSTR szEmailDisplayName, // PidLidEmail1DisplayName, PidLidEmail1OriginalEntryID
			LPWSTR szEmailAddressType, // PidLidEmail1AddressType, PidLidEmail1OriginalEntryID
			LPWSTR szEmailAddress, // PidLidEmail1EmailAddress, PidLidEmail1OriginalEntryID
			LPWSTR szEmailOriginalDisplayName, // PidLidEmail1OriginalDisplayName
			LPWSTR szCompany, // PR_COMPANY_NAME_W
			LPWSTR szBusinessStreet, // PidLidWorkAddressStreet, PR_STREET_ADDRESS_W
			LPWSTR szBusinessCity, // PidLidWorkAddressCity, PR_LOCALITY_W
			LPWSTR szBusinessState, // PidLidWorkAddressState, PR_STATE_OR_PROVINCE_W
			LPWSTR szBusinessPostalCode, // PidLidWorkAddressPostalCode, PR_POSTAL_CODE_W
			LPWSTR szBusinessCountry, // PidLidWorkAddressCountry, PR_COUNTRY_W
			LPWSTR szBusinessCountryCode, // PidLidWorkAddressCountryCode, PidLidAddressCountryCode
			LPWSTR szBusinessPhone, // PR_BUSINESS_TELEPHONE_NUMBER_W
			LPWSTR szURL, // PidLidHtml, PR_BUSINESS_HOME_PAGE_W
			LPWSTR szNotes // PR_BODY_W
			)
{
	if (!lpFolder) return MAPI_E_INVALID_PARAMETER;
	HRESULT hRes = S_OK;
	LPMESSAGE lpMessage = 0;
	// create a message and set its properties
	hRes = lpFolder->CreateMessage(0,
		0,
		&lpMessage);
	if (SUCCEEDED(hRes))
	{
		MAPINAMEID  rgnmid[ulContactProps];
		LPMAPINAMEID rgpnmid[ulContactProps];
		LPSPropTagArray lpNamedPropTags = NULL;

		ULONG i = 0;
		for (i = 0 ; i < ulContactProps ; i++)
		{
			rgnmid[i].lpguid = (LPGUID)&PSETID_Address;
			rgnmid[i].ulKind = MNID_ID;
			rgnmid[i].Kind.lID = aulContactProps[i];
			rgpnmid[i] = &rgnmid[i];
		}

		hRes = lpFolder->GetIDsFromNames(
			ulContactProps,
			(LPMAPINAMEID*) &rgpnmid,
			NULL,
			&lpNamedPropTags);
		if (SUCCEEDED(hRes) && lpNamedPropTags)
		{
			// Since we know in advance which props we'll be setting, we can statically declare most of the structures involved and save expensive MAPIAllocateBuffer calls
			SPropValue spvProps[NUM_PROPS] = {0};
			spvProps[p_PidLidFileUnderList].ulPropTag                = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidFileUnderList],PT_MV_LONG);
			spvProps[p_PidLidAutoLog].ulPropTag                      = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAutoLog],PT_BOOLEAN);
			spvProps[p_PidLidAddressBookProviderEmailList].ulPropTag = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAddressBookProviderEmailList],PT_MV_LONG);
			spvProps[p_PidLidAddressBookProviderArrayType].ulPropTag = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAddressBookProviderArrayType],PT_LONG);
			spvProps[p_PidLidFileUnder].ulPropTag                    = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidFileUnder],PT_UNICODE);
			spvProps[p_PidLidFileUnderId].ulPropTag                  = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidFileUnderId],PT_LONG);
			spvProps[p_PidLidContactCharSet].ulPropTag               = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidContactCharSet],PT_LONG);
			spvProps[p_PidLidEmail1DisplayName].ulPropTag            = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidEmail1DisplayName],PT_UNICODE);
			spvProps[p_PidLidEmail1AddressType].ulPropTag            = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidEmail1AddressType],PT_UNICODE);
			spvProps[p_PidLidEmail1EmailAddress].ulPropTag           = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidEmail1EmailAddress],PT_UNICODE);
			spvProps[p_PidLidEmail1OriginalDisplayName].ulPropTag    = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidEmail1OriginalDisplayName],PT_UNICODE);
			spvProps[p_PidLidEmail1OriginalEntryID].ulPropTag        = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidEmail1OriginalEntryID],PT_BINARY);
			spvProps[p_PidLidWorkAddressStreet].ulPropTag            = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidWorkAddressStreet],PT_UNICODE);
			spvProps[p_PidLidWorkAddressCity].ulPropTag              = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidWorkAddressCity],PT_UNICODE);
			spvProps[p_PidLidWorkAddressState].ulPropTag             = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidWorkAddressState],PT_UNICODE);
			spvProps[p_PidLidWorkAddressPostalCode].ulPropTag        = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidWorkAddressPostalCode],PT_UNICODE);
			spvProps[p_PidLidWorkAddressCountry].ulPropTag           = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidWorkAddressCountry],PT_UNICODE);
			spvProps[p_PidLidWorkAddressCountryCode].ulPropTag       = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidWorkAddressCountryCode],PT_UNICODE);
			spvProps[p_PidLidPostalAddressId].ulPropTag              = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidPostalAddressId],PT_LONG);
			spvProps[p_PidLidAddressCountryCode].ulPropTag           = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAddressCountryCode],PT_UNICODE);

			spvProps[p_PidLidContactItemData].ulPropTag              = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidContactItemData],PT_MV_LONG);
			spvProps[p_PidLidHtml].ulPropTag                         = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidHtml],PT_UNICODE);

			spvProps[p_PR_DISPLAY_NAME_PREFIX_W].ulPropTag           = PR_DISPLAY_NAME_PREFIX_W;
			spvProps[p_PR_SURNAME_W].ulPropTag                       = PR_SURNAME_W;
			spvProps[p_PR_MIDDLE_NAME_W].ulPropTag                   = PR_MIDDLE_NAME_W;
			spvProps[p_PR_GIVEN_NAME_W].ulPropTag                    = PR_GIVEN_NAME_W;
			spvProps[p_PR_GENERATION_W].ulPropTag                    = PR_GENERATION_W;
			spvProps[p_PR_INITIALS_W].ulPropTag                      = PR_INITIALS_W;
			spvProps[p_PR_COMPANY_NAME_W].ulPropTag                  = PR_COMPANY_NAME_W;
			spvProps[p_PR_BUSINESS_HOME_PAGE_W].ulPropTag            = PR_BUSINESS_HOME_PAGE_W;
			spvProps[p_PR_BUSINESS_TELEPHONE_NUMBER_W].ulPropTag     = PR_BUSINESS_TELEPHONE_NUMBER_W;
			spvProps[p_PR_STREET_ADDRESS_W].ulPropTag                = PR_STREET_ADDRESS_W;
			spvProps[p_PR_LOCALITY_W].ulPropTag                      = PR_LOCALITY_W;
			spvProps[p_PR_STATE_OR_PROVINCE_W].ulPropTag             = PR_STATE_OR_PROVINCE_W;
			spvProps[p_PR_POSTAL_CODE_W].ulPropTag                   = PR_POSTAL_CODE_W;
			spvProps[p_PR_COUNTRY_W].ulPropTag                       = PR_COUNTRY_W;
			spvProps[p_PR_DISPLAY_NAME_W].ulPropTag                  = PR_DISPLAY_NAME_W;
			spvProps[p_PR_MESSAGE_CLASS_W].ulPropTag                 = PR_MESSAGE_CLASS_W;
			spvProps[p_PR_ICON_INDEX].ulPropTag                      = PR_ICON_INDEX;
			spvProps[p_PR_SUBJECT_PREFIX_W].ulPropTag                = PR_SUBJECT_PREFIX_W;
			spvProps[p_PR_SUBJECT_W].ulPropTag                       = PR_SUBJECT_W;
			spvProps[p_PR_BODY_W].ulPropTag                          = PR_BODY_W;

			spvProps[p_PidLidFileUnderList].Value.MVl.cValues = 5;
			LONG lFileUnder[5];
			lFileUnder[0] = 0x00008017; // Surname, Given Middle
			lFileUnder[1] = 0x00008037; // Given Middle Surname Generation
			lFileUnder[2] = 0x00003a16; // Company Name (PR_COMPANY_NAME)
			lFileUnder[3] = 0x00008019; // Surname, Given Middle\r\nCompany Name
			lFileUnder[4] = 0x00008018; // Company Name\r\nSurname, Given Middle
			spvProps[p_PidLidFileUnderList].Value.MVl.lpl = lFileUnder;

			spvProps[p_PidLidAutoLog].Value.b = false; // Do not journal

			spvProps[p_PidLidAddressBookProviderEmailList].Value.MVl.cValues = 1;
			LONG lAddressBookProviderEmail[1];
			lAddressBookProviderEmail[0] = 0x00000000; // Email1 is defined
			spvProps[p_PidLidAddressBookProviderEmailList].Value.MVl.lpl = lAddressBookProviderEmail;

			spvProps[p_PidLidAddressBookProviderArrayType].Value.l = 0x0000001; // Email1 is defined

			spvProps[p_PidLidFileUnder].Value.lpszW = szFileUnder;

			spvProps[p_PidLidFileUnderId].Value.l = 0x8017; // Surname, Given Middle
			spvProps[p_PidLidContactCharSet].Value.l = 0x00000100; // generic value denoting "western" character set
			spvProps[p_PidLidEmail1DisplayName].Value.lpszW = szEmailDisplayName;
			spvProps[p_PidLidEmail1AddressType].Value.lpszW = szEmailAddressType;
			spvProps[p_PidLidEmail1EmailAddress].Value.lpszW = szEmailAddress;
			spvProps[p_PidLidEmail1OriginalDisplayName].Value.lpszW = szEmailOriginalDisplayName;

			spvProps[p_PidLidWorkAddressStreet].Value.lpszW = szBusinessStreet;
			spvProps[p_PidLidWorkAddressCity].Value.lpszW = szBusinessCity;
			spvProps[p_PidLidWorkAddressState].Value.lpszW = szBusinessState;
			spvProps[p_PidLidWorkAddressPostalCode].Value.lpszW = szBusinessPostalCode;
			spvProps[p_PidLidWorkAddressCountry].Value.lpszW = szBusinessCountry;
			spvProps[p_PidLidWorkAddressCountryCode].Value.lpszW = szBusinessCountryCode;

			spvProps[p_PidLidPostalAddressId].Value.l = 2; // Work address is mailing address
			spvProps[p_PR_STREET_ADDRESS_W].Value.lpszW = szBusinessStreet;
			spvProps[p_PR_LOCALITY_W].Value.lpszW = szBusinessCity;
			spvProps[p_PR_STATE_OR_PROVINCE_W].Value.lpszW = szBusinessState;
			spvProps[p_PR_POSTAL_CODE_W].Value.lpszW = szBusinessPostalCode;
			spvProps[p_PR_COUNTRY_W].Value.lpszW = szBusinessCountry;
			spvProps[p_PidLidAddressCountryCode].Value.lpszW = szBusinessCountryCode;

			spvProps[p_PidLidContactItemData].Value.MVl.cValues = 6;
			LONG lContactItemData[6];
			lContactItemData[0] = 0x00000002; // Display work address
			lContactItemData[1] = 0x00008080; // Display Email 1 (PidLidEmail1DisplayName)
			lContactItemData[2] = 0x3A08; // Display Business Telephone (PR_BUSINESS_TELEPHONE_NUMBER)
			lContactItemData[3] = 0x3A09; // Display Home Telephone (PR_HOME_TELEPHONE_NUMBER)
			lContactItemData[4] = 0x3A24; // Display Business Fax (PR_BUSINESS_FAX_NUMBER)
			lContactItemData[5] = 0x3A1C; // Display Mobile Telephone (PR_MOBILE_TELEPHONE_NUMBER)
			spvProps[p_PidLidContactItemData].Value.MVl.lpl = lContactItemData;

			// These two must be the same
			spvProps[p_PidLidHtml].Value.lpszW = szURL;
			spvProps[p_PR_BUSINESS_HOME_PAGE_W].Value.lpszW = szURL;

			spvProps[p_PR_DISPLAY_NAME_PREFIX_W].Value.lpszW = L"";
			spvProps[p_PR_SURNAME_W].Value.lpszW = szSurName;
			spvProps[p_PR_MIDDLE_NAME_W].Value.lpszW = szMiddleName;
			spvProps[p_PR_GIVEN_NAME_W].Value.lpszW = szGivenName;
			spvProps[p_PR_GENERATION_W].Value.lpszW = L"";
			spvProps[p_PR_INITIALS_W].Value.lpszW = szInitials;
			spvProps[p_PR_COMPANY_NAME_W].Value.lpszW = szCompany;
			spvProps[p_PR_BUSINESS_TELEPHONE_NUMBER_W].Value.lpszW = szBusinessPhone;
			spvProps[p_PR_DISPLAY_NAME_W].Value.lpszW = szFullName;
			spvProps[p_PR_MESSAGE_CLASS_W].Value.lpszW = L"IPM.Contact";
			spvProps[p_PR_ICON_INDEX].Value.l = 512; // Contact icon
			spvProps[p_PR_SUBJECT_PREFIX_W].Value.lpszW = L"";
			spvProps[p_PR_SUBJECT_W].Value.lpszW = szFullName;
			spvProps[p_PR_BODY_W].Value.lpszW = szNotes;

			hRes = BuildOneOff(
				szEmailDisplayName,
				szEmailAddressType,
				szEmailAddress,
				&spvProps[p_PidLidEmail1OriginalEntryID].Value.bin.cb,
				&spvProps[p_PidLidEmail1OriginalEntryID].Value.bin.lpb);
			if (SUCCEEDED(hRes))
			{
				hRes = lpMessage->SetProps(NUM_PROPS, spvProps, NULL);
				if (SUCCEEDED(hRes))
				{
					hRes = lpMessage->SaveChanges(FORCE_SAVE);
				}
			}
			if (spvProps[p_PidLidEmail1OriginalEntryID].Value.bin.lpb)
				delete[] spvProps[p_PidLidEmail1OriginalEntryID].Value.bin.lpb;
		}
		MAPIFreeBuffer(lpNamedPropTags);
	}
	if (lpMessage) lpMessage->Release();
	return hRes;
}

_AddInDialogControl g_ContactControls[] =
{
	// {type,readonly,multiline,defaultcheckstate,defaultvalue(number),text label,defaultvalue(text),cbBin,lpBin}
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Full Name", L"Stephen Griffin",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Given Name", L"Stephen",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Middle Name", L"",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Surname Name", L"Griffin",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Initials", L"S. G.",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"File Under", L"Griffin, Stephen",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"E-mail Display Name", L"Stephen Griffin (someone@example.com)",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"E-mail Address Type", L"SMTP",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"E-mail Address", L"someone@example.com",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"E-mail Original Display Name", L"someone@example.com",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Company", L"Microsoft",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Business Address Street", L"1 Microsoft Way",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Business Address City", L"Redmond",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Business Address State", L"WA",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Business Address Postal Code", L"98052",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Business Address Country", L"United States of America",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Business Address Country Code", L"US",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Business Phone Number", L"555-1234",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"URL", L"http://codeplex.com/mfcmapi",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Notes", L"This is a sample note",0,0},
};
void DisplayAddContactDialog(LPMAPIFOLDER lpFolder)
{
	LPCOMPLEXDIALOG pfnComplexDialog = (LPCOMPLEXDIALOG) GetProcAddress(GetModuleHandle(NULL),szComplexDialog);
	LPFREEDIALOGRESULT pfnFreeDialogResult = (LPFREEDIALOGRESULT) GetProcAddress(GetModuleHandle(NULL),szFreeDialogResult);
	if (pfnComplexDialog && pfnFreeDialogResult)
	{
		_AddInDialog myDialog = {0};
		myDialog.szTitle = L"Add Contact";
		myDialog.szPrompt = L"Thus function creates a contact in the current folder\r\n";
		myDialog.ulButtonFlags = CEDITOR_BUTTON_OK;
		myDialog.ulNumControls = sizeof(g_ContactControls)/sizeof(_AddInDialogControl);
		myDialog.lpDialogControls = g_ContactControls;

		LPADDINDIALOGRESULT lpDialogResult = NULL;

		pfnComplexDialog(&myDialog,&lpDialogResult);
		if (lpDialogResult)
		{
			ULONG i = 0;
			LPWSTR szFullName = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szGivenName = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szMiddleName = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szSurName = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szInitials = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szFileUnder = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szEmailDisplayName = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szEmailAddressType = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szEmailAddress = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szEmailOriginalDisplayName = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szCompany = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szBusinessStreet = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szBusinessCity = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szBusinessState = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szBusinessPostalCode = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szBusinessCountry = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szBusinessCountryCode = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szBusinessPhone = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szURL = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szNotes = lpDialogResult->lpDialogControlResults[i++].szText;
			(void) AddContact(lpFolder,
				szFullName,
				szGivenName,
				szMiddleName,
				szSurName,
				szInitials,
				szFileUnder,
				szEmailDisplayName,
				szEmailAddressType,
				szEmailAddress,
				szEmailOriginalDisplayName,
				szCompany,
				szBusinessStreet,
				szBusinessCity,
				szBusinessState,
				szBusinessPostalCode,
				szBusinessCountry,
				szBusinessCountryCode,
				szBusinessPhone,
				szURL,
				szNotes);
		}
		pfnFreeDialogResult(lpDialogResult);
	}
}
