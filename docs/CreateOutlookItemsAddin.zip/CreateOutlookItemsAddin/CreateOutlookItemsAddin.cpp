#include "CreateOutlookItemsAddin.h"
#include <initguid.h>

LPADDINLOG AddInLog = NULL;
WCHAR* g_szAddInName = L"CreateOutlookItemsAddin";

BOOL WINAPI DllMain(HINSTANCE /*hinstDLL*/, DWORD /*fdwReason*/, LPVOID /*lpvReserved*/)
{
	return true;
}

// LoadAddIn - Let the add-in know we're here, get its name.
// If this function is not present, we won't load the add-in
void STDMETHODCALLTYPE LoadAddIn(LPWSTR* szName)
{
	// Get our logging routine
	HMODULE hMod = GetModuleHandle(NULL);
	AddInLog = (LPADDINLOG) GetProcAddress(hMod,szAddInLog);
	AddInLog(true,L"%s loading\n",g_szAddInName);
	*szName = g_szAddInName;
}

// UnloadAddIn - let the add-in know we're done - it should free any resources it has allocated
void STDMETHODCALLTYPE UnloadAddIn()
{
	AddInLog(true,L"%s unloading\n",g_szAddInName);
}

_MenuItem g_MyMenus[] = {
	{L"Add Appointment",L"Add an appointment to the current folder",MENU_CONTEXT_FOLDER_TREE,MENU_FLAGS_SINGLESELECT|MENU_FLAGS_REQUESTMODIFY,0},
	{L"Add Appointment",L"Add an appointment to the current folder",MENU_CONTEXT_FOLDER_CONTENTS,MENU_FLAGS_REQUESTMODIFY,1},
	{L"Add Contact",L"Add a contact to the current folder",MENU_CONTEXT_FOLDER_TREE,MENU_FLAGS_SINGLESELECT|MENU_FLAGS_REQUESTMODIFY,2},
	{L"Add Contact",L"Add a contact to the current folder",MENU_CONTEXT_FOLDER_CONTENTS,MENU_FLAGS_REQUESTMODIFY,3},
	{L"Add Mail",L"Add a mail to the current folder",MENU_CONTEXT_FOLDER_TREE,MENU_FLAGS_SINGLESELECT|MENU_FLAGS_REQUESTMODIFY,4},
	{L"Add Mail",L"Add a mail to the current folder",MENU_CONTEXT_FOLDER_CONTENTS,MENU_FLAGS_REQUESTMODIFY,5},
	{L"Add Task",L"Add a task to the current folder",MENU_CONTEXT_FOLDER_TREE,MENU_FLAGS_SINGLESELECT|MENU_FLAGS_REQUESTMODIFY,6},
	{L"Add Task",L"Add a task to the current folder",MENU_CONTEXT_FOLDER_CONTENTS,MENU_FLAGS_REQUESTMODIFY,7},
	};

// GetMenus - returns static array of menu information - no function pointers - just context numbers
void STDMETHODCALLTYPE GetMenus(ULONG* lpulMenu, LPMENUITEM* lppMenu)
{
	if (!lpulMenu || !lppMenu) return;
	*lpulMenu = sizeof(g_MyMenus)/sizeof(_MenuItem);
	*lppMenu = g_MyMenus;
}

LPMAPIFREEBUFFER pfnMAPIFreeBuffer = NULL;
LPGETMAPIMODULE pfnGetMAPIModule = NULL;
LPMAPIALLOCATEBUFFER pfnMAPIAllocateBuffer = NULL;
typedef void (STDMETHODCALLTYPE FREEPADRLIST)(
					LPADRLIST lpAdrList);
typedef FREEPADRLIST *LPFREEPADRLIST;
LPFREEPADRLIST pfnFreePadrlist = NULL;

void GetMAPIModule(HMODULE* lphModule, BOOL bForce)
{
	if (!lphModule) return;
	*lphModule = NULL;
	if (!pfnGetMAPIModule)
	{
		pfnGetMAPIModule = (LPGETMAPIMODULE) GetProcAddress(GetModuleHandle(NULL),szGetMAPIModule);
		AddInLog(true,L"pfnGetMAPIModule = 0x%08X\n",pfnMAPIFreeBuffer);
	}
	if (pfnGetMAPIModule)
	{
		pfnGetMAPIModule(lphModule,bForce);
		AddInLog(true,L"hModule = 0x%08X\n",*lphModule);
	}
}

STDAPI_(ULONG_PTR) MAPIFreeBuffer(LPVOID lpBuffer)
{
	if (!lpBuffer) return NULL;

	if (!pfnMAPIFreeBuffer)
	{
		HMODULE hMAPI = NULL;
		GetMAPIModule(&hMAPI,false);
		if (hMAPI)
		{
			pfnMAPIFreeBuffer = (LPMAPIFREEBUFFER) GetProcAddress(hMAPI,"MAPIFreeBuffer");
			AddInLog(true,L"pfnMAPIFreeBuffer = 0x%08X\n",pfnMAPIFreeBuffer);
		}
	}
	if (pfnMAPIFreeBuffer) return pfnMAPIFreeBuffer(lpBuffer);
	return NULL;
}

STDMETHODIMP_(SCODE) MAPIAllocateBuffer(ULONG cbSize,
										LPVOID FAR * lppBuffer)
{
	if (!lppBuffer) return NULL;

	if (!pfnMAPIAllocateBuffer)
	{
		HMODULE hMAPI = NULL;
		GetMAPIModule(&hMAPI,false);
		if (hMAPI)
		{
			pfnMAPIAllocateBuffer = (LPMAPIALLOCATEBUFFER) GetProcAddress(hMAPI,"MAPIAllocateBuffer");
			AddInLog(true,L"pfnMAPIAllocateBuffer = 0x%08X\n",pfnMAPIAllocateBuffer);
		}
	}
	if (pfnMAPIAllocateBuffer) return pfnMAPIAllocateBuffer(cbSize,lppBuffer);
	return NULL;
}

STDAPI_(void) FreePadrlist(LPADRLIST lpAdrlist)
{
	if (!lpAdrlist) return;

	if (!pfnMAPIAllocateBuffer)
	{
		HMODULE hMAPI = NULL;
		GetMAPIModule(&hMAPI,false);
		if (hMAPI)
		{
			pfnFreePadrlist = (LPFREEPADRLIST) GetProcAddress(hMAPI,"FreePadrlist@4");
			if (pfnFreePadrlist) pfnFreePadrlist = (LPFREEPADRLIST) GetProcAddress(hMAPI,"FreePadrlist");
			AddInLog(true,L"pfnFreePadrlist = 0x%08X\n",pfnFreePadrlist);
		}
	}
	if (pfnFreePadrlist) pfnFreePadrlist(lpAdrlist);
	return ;
}

// CallMenu - calls back to AddIn with a menu choice - addin will decode and invoke
HRESULT STDMETHODCALLTYPE CallMenu(
				 LPADDINMENUPARAMS lpParams	// Everything the add-in needs to know
				 )
{
	HRESULT	hRes = S_OK;
	AddInLog(true,L"CallMenu: Congratulations! You have just extended MFCMAPI!\n");
	if (!lpParams) return MAPI_E_INVALID_PARAMETER;

	if (lpParams->lpAddInMenu)
	{
		switch (lpParams->lpAddInMenu->ulID)
		{
		case 0 :
		case 1 :
			{
				DisplayAddAppointmentDialog(lpParams->lpFolder);
				break;
			}
		case 2 :
		case 3 :
			{
				DisplayAddContactDialog(lpParams->lpFolder);
				break;
			}
		case 4 :
		case 5 :
			{
				DisplayAddMailDialog(lpParams->lpMAPISession,lpParams->lpFolder);
				break;
			}
		case 6 :
		case 7 :
			{
				DisplayAddTaskDialog(lpParams->lpFolder);
				break;
			}
		default:
			{
				break;
			}
		}
	}

	AddInLog(true,L"CallMenu: Done - returning hRes = 0x%08X\n",hRes);
	return hRes;
}

DWORD SystemTimeToRTime(LPSYSTEMTIME lpSystemTime)
{
	FILETIME ft = {0};
	if (SystemTimeToFileTime(lpSystemTime,&ft))
	{
		LARGE_INTEGER liNumSec = {0};
		liNumSec.LowPart = ft.dwLowDateTime;
		liNumSec.HighPart = ft.dwHighDateTime;
		// Resolution of RTime is in minutes, FILETIME is in 100 nanosecond intervals
		// Scale between the two is 10000000*60
		liNumSec.QuadPart = liNumSec.QuadPart/(10000000*60);
		return (DWORD) liNumSec.QuadPart;
	}
	return NULL;
}

// Build ConversationIndex - does basically what ScCreateConversationIndex does when passed a NULL parent
// Allocates with new, free with delete[]
HRESULT BuildConversationIndex(ULONG* lpcbConversationIndex,
							   LPBYTE* lppConversationIndex)
{
	if (!lpcbConversationIndex || !lppConversationIndex) return MAPI_E_INVALID_PARAMETER;

	HRESULT hRes = S_OK;

	*lpcbConversationIndex = NULL;
	*lppConversationIndex = NULL;

	// Calculate how large our struct will be
	size_t cbStruct = sizeof(BYTE) + // UnnamedByte
		5 * sizeof(BYTE) + // ftCurrent
		sizeof(GUID); // guid

	// Allocate our buffer
	LPBYTE lpConversationIndex = new BYTE[cbStruct];

	// Populate it
	if (lpConversationIndex)
	{
		memset(lpConversationIndex,0,cbStruct);
		lpConversationIndex[0] = 0x1;

		SYSTEMTIME st = {0};
		FILETIME ft = {0};
		GUID guid = {0};
		GetSystemTime(&st);
		SystemTimeToFileTime(&st,&ft);

		lpConversationIndex[1] = (BYTE) ((ft.dwHighDateTime & 0x00FF0000) >> 16);
		lpConversationIndex[2] = (BYTE) ((ft.dwHighDateTime & 0x0000FF00) >> 8);
		lpConversationIndex[3] = (BYTE)  (ft.dwHighDateTime & 0x000000FF);
		lpConversationIndex[4] = (BYTE) ((ft.dwLowDateTime  & 0xFF000000) >> 24);
		lpConversationIndex[5] = (BYTE) ((ft.dwLowDateTime  & 0x00FF0000) >> 16);
		hRes = CoCreateGuid(&guid);
		if (SUCCEEDED(hRes))
		{
			lpConversationIndex[6] =  (BYTE) ((guid.Data1 & 0xFF000000) >> 24);
			lpConversationIndex[7] =  (BYTE) ((guid.Data1 & 0x00FF0000) >> 16);
			lpConversationIndex[8] =  (BYTE) ((guid.Data1 & 0x0000FF00) >> 8);
			lpConversationIndex[9] =  (BYTE) ((guid.Data1 & 0x000000FF));
			lpConversationIndex[10] = (BYTE) ((guid.Data2 & 0xFF00) >> 8);
			lpConversationIndex[11] = (BYTE) ((guid.Data2 & 0x00FF));
			lpConversationIndex[12] = (BYTE) ((guid.Data3 & 0xFF00) >> 8);
			lpConversationIndex[13] = (BYTE) ((guid.Data3 & 0x00FF));
			memcpy (&lpConversationIndex[14], &guid.Data4, 8);
			// Return it
			*lpcbConversationIndex = cbStruct;
			*lppConversationIndex = lpConversationIndex;
			return S_OK;
		}
	}

	// We can only get here if we failed
	return FAILED(hRes)?hRes:MAPI_E_CALL_FAILED;
}
