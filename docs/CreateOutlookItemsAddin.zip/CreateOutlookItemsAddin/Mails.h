#pragma once

void DisplayAddMailDialog(LPMAPISESSION lpMAPISession, LPMAPIFOLDER lpFolder);