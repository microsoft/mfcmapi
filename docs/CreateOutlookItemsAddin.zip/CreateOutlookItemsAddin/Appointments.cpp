#include "CreateOutlookItemsAddin.h"
#include <initguid.h>

DEFINE_OLEGUID(PSETID_Appointment, MAKELONG(0x2000+(0x2),0x0006),0,0);
DEFINE_GUID(PSETID_Meeting, MAKELONG(0xDA90, 0x6ED8),0x450B, 0x101B, 0x98, 0xDA, 0x0, 0xAA, 0x0, 0x3F, 0x13, 0x05);
DEFINE_OLEGUID(PSETID_Common, MAKELONG(0x2000+(0x8),0x0006),0,0);

typedef enum OlBusyStatus {
	olFree=0,
	olTentative=1,
	olBusy=2,
	olOutOfOffice=3,
} OlBusyStatus;

#define	respNone			0
#define rectypeWeekly	(int) 2

#define seOpenToDelete		0x0001	// Additional processing is required on the Message object when deleting.
#define seCoerceToInbox		0x0010	// Additional processing is required on the Message object when moving or
                                    // copying to a Folder object with a PR_CONTAINER_CLASS of �IPF.Note�.
#define seOpenToCopy		0x0020	// Additional processing is required on the Message object when copying to
                                    // another folder.
#define seOpenToMove		0x0040	// Additional processing is required on the Message object when moving to
                                    // another folder.
#define seOpenForCtxMenu    0x0100  // Additional processing is required on the Message object when displaying verbs
                                    // to the end-user.

const WORD TZRULE_FLAG_EFFECTIVE_TZREG      = 0x0002;
const BYTE	TZ_BIN_VERSION_MAJOR	= 0x02;
const BYTE	TZ_BIN_VERSION_MINOR	= 0x01;

#define PidLidAppointmentSequence 0x8201
#define PidLidBusyStatus 0x8205
#define PidLidLocation 0x8208
#define PidLidAppointmentStartWhole 0x820D
#define PidLidAppointmentEndWhole 0x820E
#define PidLidAppointmentDuration 0x8213
#define PidLidAppointmentColor 0x8214
#define PidLidResponseStatus 0x8218
#define PidLidRecurring 0x8223
#define PidLidClipStart 0x8235
#define PidLidClipEnd 0x8236
#define PidLidTimeZoneStruct 0x8233
#define PidLidTimeZoneDescription 0x8234
#define PidLidAppointmentTimeZoneDefinitionRecur 0x8260
#define PidLidAppointmentTimeZoneDefinitionStartDisplay 0x825E
#define PidLidAppointmentTimeZoneDefinitionEndDisplay 0x825F
#define PidLidAppointmentRecur 0x8216
#define PidLidRecurrenceType 0x8231
#define PidLidRecurrencePattern 0x8232
#define PidLidIsRecurring 0x0005
#define PidLidGlobalObjectId 0x0003
#define PidLidCleanGlobalObjectId 0x0023
#define PidLidCommonStart 0x8516
#define PidLidCommonEnd 0x8517
#define PidLidSideEffects 0x8510

// Allocates with new, free with delete
// The following code builds a time zone structure
HRESULT BuildTimeZoneStruct(
							DWORD dwBias,
							DWORD dwStandardBias,
							DWORD dwDaylightBias,
							SYSTEMTIME* lpstStandardDate,
							SYSTEMTIME* lpstDaylightDate,
							ULONG* lpcbTZ,
							LPBYTE* lppTZ)
{
	if (!lpcbTZ || !lppTZ || !lpstStandardDate || !lpstDaylightDate) return MAPI_E_INVALID_PARAMETER;

	// Calculate how large our time zone structure will be
	size_t cbTZ = sizeof(DWORD)*3 + // lBias, lStandardBias, lDaylightBias
		sizeof(WORD) + // wStandardYear
		sizeof(SYSTEMTIME) + // stStandardDate
		sizeof(WORD) + // wDaylightYear
		sizeof(SYSTEMTIME); // stDaylightDate

	// Allocate our buffer
	LPBYTE lpTZ = new BYTE[cbTZ];

	// Populate it
	if (lpTZ)
	{
		memset(lpTZ,0,cbTZ);

		LPBYTE pb = lpTZ;
		*(DWORD*)pb = dwBias; // lBias
		pb += sizeof(DWORD);
		*(DWORD*)pb = dwStandardBias; // lStandardBias
		pb += sizeof(DWORD);
		*(DWORD*)pb = dwDaylightBias; // lDaylightBias
		pb += sizeof(DWORD);
		*(WORD*)pb = lpstStandardDate->wYear; // wStandardYear
		pb += sizeof(WORD);
		*(SYSTEMTIME*)pb = *lpstStandardDate; // stStandardDate
		pb += sizeof(SYSTEMTIME);
		*(WORD*)pb = lpstDaylightDate->wYear; // wStandardYear
		pb += sizeof(WORD);
		*(SYSTEMTIME*)pb = *lpstDaylightDate; // stStandardDate
		pb += sizeof(SYSTEMTIME);

		// Return it
		*lpcbTZ = cbTZ;
		*lppTZ = (LPBYTE) lpTZ;
		return S_OK;
	}

	return MAPI_E_CALL_FAILED;
}

// Allocates with new, free with delete
// The following code builds a time zone definition with two rules
HRESULT BuildTimeZoneDefinition(
								LPWSTR lpszKeyName,
								WORD wRule1Flags,
								WORD wRule1Year,
								DWORD dwRule1Bias,
								DWORD dwRule1StandardBias,
								DWORD dwRule1DaylightBias,
								SYSTEMTIME* lpstRule1StandardDate,
								SYSTEMTIME* lpstRule1DaylightDate,
								WORD wRule2Flags,
								WORD wRule2Year,
								DWORD dwRule2Bias,
								DWORD dwRule2StandardBias,
								DWORD dwRule2DaylightBias,
								SYSTEMTIME* lpstRule2StandardDate,
								SYSTEMTIME* lpstRule2DaylightDate,
								ULONG* lpcbTZ,
								LPBYTE* lppTZ)
{
	if (!lpcbTZ || !lppTZ ||
		!lpstRule1StandardDate || !lpstRule1DaylightDate ||
		!lpstRule2StandardDate || !lpstRule2DaylightDate)
		return MAPI_E_INVALID_PARAMETER;

	size_t cchKeyName = NULL;
	if (lpszKeyName) cchKeyName = wcslen(lpszKeyName); // Do not count the NULL terminator

	// Calculate how large our time zone definition will be
	size_t cbTZ = sizeof(BYTE)*2 + // Major Version, Minor Version
		sizeof(WORD)*3 + // cbHeader, Reserved, cchKeyName
		sizeof(WCHAR)*cchKeyName +
		sizeof(WORD) + // cRules
		2 * ( // Adding two rules
			sizeof(BYTE)*2 + // Major Version, Minor Version
			sizeof(WORD)*3 + // Reserved, TZRuleFlags, wYear
			sizeof(DWORD)*3 + sizeof(WORD) + // X
			sizeof(DWORD)*3 + // lBias, lStandardBias, lDaylightBias
			sizeof(SYSTEMTIME) + // stStandardDate
			sizeof(SYSTEMTIME) // stDaylightDate
		);

	// Allocate our buffer
	LPBYTE lpTZ = new BYTE[cbTZ];

	// Populate it
	if (lpTZ)
	{
		memset(lpTZ,0,cbTZ);

		LPBYTE pb = lpTZ;
		*(BYTE*)pb = TZ_BIN_VERSION_MAJOR; // Major Version
		pb += sizeof(BYTE);
		*(BYTE*)pb = TZ_BIN_VERSION_MINOR; // Minor Version
		pb += sizeof(BYTE);
		*(WORD*)pb = (WORD) (sizeof(WORD)*2 + sizeof(WCHAR)*cchKeyName + sizeof(WORD)); // cbHeader
		pb += sizeof(WORD);
		*(WORD*)pb = 2; // Reserved
		pb += sizeof(WORD);
		*((WORD*)pb) = (WORD) cchKeyName;
		pb += sizeof(WORD);
		if (cchKeyName)
		{
			memcpy(pb,lpszKeyName,cchKeyName * sizeof(WCHAR));
			pb += cchKeyName * sizeof(WCHAR);
		}
		*(WORD*)pb = 2; // cRules
		pb += sizeof(WORD);

		// Rule 1
		*(BYTE*)pb = TZ_BIN_VERSION_MAJOR; // Major Version
		pb += sizeof(BYTE);
		*(BYTE*)pb = TZ_BIN_VERSION_MINOR; // Minor Version
		pb += sizeof(BYTE);
		*(WORD*)pb = 0x003E; // Reserved
		pb += sizeof(WORD);
		*((WORD*)pb) = wRule1Flags; // TZRule Flags
		pb += sizeof(WORD);
		*((WORD*)pb) = wRule1Year; // wYear
		pb += sizeof(WORD);
		pb += sizeof(DWORD)*3 + sizeof(WORD); // X
		*((DWORD*)pb) = dwRule1Bias; // lBias
		pb += sizeof(DWORD);
		*((DWORD*)pb) = dwRule1StandardBias; // lStandardBias
		pb += sizeof(DWORD);
		*((DWORD*)pb) = dwRule1DaylightBias; // lDaylightBias
		pb += sizeof(DWORD);
		*(SYSTEMTIME*)pb = *lpstRule1StandardDate; // stStandardDate
		pb += sizeof(SYSTEMTIME);
		*(SYSTEMTIME*)pb = *lpstRule1DaylightDate; // stDaylightDate
		pb += sizeof(SYSTEMTIME);

		// Rule 2
		*(BYTE*)pb = TZ_BIN_VERSION_MAJOR; // Major Version
		pb += sizeof(BYTE);
		*(BYTE*)pb = TZ_BIN_VERSION_MAJOR; // Minor Version
		pb += sizeof(BYTE);
		*(WORD*)pb = 0x003E; // Reserved
		pb += sizeof(WORD);
		*((WORD*)pb) = wRule2Flags; // TZRule Flags
		pb += sizeof(WORD);
		*((WORD*)pb) = wRule2Year; // wYear
		pb += sizeof(WORD);
		pb += sizeof(DWORD)*3 + sizeof(WORD); // X
		*((DWORD*)pb) = dwRule2Bias; // lBias
		pb += sizeof(DWORD);
		*((DWORD*)pb) = dwRule2StandardBias; // lStandardBias
		pb += sizeof(DWORD);
		*((DWORD*)pb) = dwRule2DaylightBias; // lDaylightBias
		pb += sizeof(DWORD);
		*(SYSTEMTIME*)pb = *lpstRule2StandardDate; // stStandardDate
		pb += sizeof(SYSTEMTIME);
		*(SYSTEMTIME*)pb = *lpstRule2DaylightDate; // stDaylightDate
		pb += sizeof(SYSTEMTIME);

		// Return it
		*lpcbTZ = cbTZ;
		*lppTZ = (LPBYTE) lpTZ;
		return S_OK;
	}

	return MAPI_E_CALL_FAILED;
}

// Allocates with new, free with delete
// The following code builds a recurrence pattern
HRESULT BuildWeeklyAppointmentRecurrencePattern(
	SYSTEMTIME* lpstStartDateLocal,
	SYSTEMTIME* lpstEndDateLocal,
	SYSTEMTIME* lpstFirstDOW,
	DWORD dwStartOffsetLocal,
	DWORD dwEndOffsetLocal,
	DWORD dwPeriod,
	DWORD dwOccurrenceCount,
	DWORD dwPatternTypeSpecific,
	ULONG* lpcbRecur,
	LPBYTE* lppRecur)
{
	if (!lpcbRecur || !lppRecur || !lpstStartDateLocal || !lpstEndDateLocal || !lpstFirstDOW) return MAPI_E_INVALID_PARAMETER;

	// Calculate how large our weekly recurrence pattern will be
	size_t cbRecur = sizeof(WORD)*5 + // ReaderVersion, WriterVersion, RecurFrequency, PatternType, CalendarType
		sizeof(DWORD)*3 + // FirstDateTime, Period, SlidingFlag
		sizeof(DWORD) + // PatternTypeSpecific
		sizeof(DWORD)*7 + // EndType, OccurrenceCount, FirstDOW, DeletedInstanceCount(0), ModifiedInstanceCount(0), StartDate, EndDate
		sizeof(DWORD)*4 + // ReaderVersion2, WriterVersion2, StartTimeOffset, EndTimeOffset
		sizeof(WORD) + // ExceptionCount(0)
		sizeof(DWORD)*2; // ReservedBlock1Size(0), ReservedBlock2Size(0)

	// Allocate our buffer
	LPBYTE lpRecur = new BYTE[cbRecur];

	// Populate it
	if (lpRecur)
	{
		memset(lpRecur,0,cbRecur);

		LPBYTE pb = lpRecur;
		// Recurrence Pattern sub-structure
		*(WORD*)pb = 0x3004; // ReaderVersion
		pb += sizeof(WORD);
		*(WORD*)pb = 0x3004; // WriterVersion
		pb += sizeof(WORD);
		*(WORD*)pb = IDC_RCEV_PAT_ORB_WEEKLY; // RecurFrequency - The pattern of the recurrence is weekly.
		pb += sizeof(WORD);
		*(WORD*)pb = rptWeek; // PatternType - The pattern type is Week
		pb += sizeof(WORD);
		*(WORD*)pb = CAL_DEFAULT; // CalendarType - The calendar type is Gregorian
		pb += sizeof(WORD);
		*(DWORD*)pb = SystemTimeToRTime(lpstFirstDOW) % (10080*dwPeriod); // FirstDateTime
		pb += sizeof(DWORD);
		*(DWORD*)pb = dwPeriod; // Period
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0x00000000; // SlidingFlag - The recurring instances do not rely on completion of the previous Instances.
		pb += sizeof(DWORD);
		*(DWORD*)pb = dwPatternTypeSpecific; // PatternTypeSpecific
		pb += sizeof(DWORD);
		*(DWORD*)pb = IDC_RCEV_PAT_ERB_AFTERNOCCUR; // EndType - End after N occurrences.
		pb += sizeof(DWORD);
		*(DWORD*)pb = dwOccurrenceCount; // OccurrenceCount
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0x00000000; // FirstDOW - The first day of the week on the calendar is Sunday
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0x00000000; // DeletedInstanceCount - There are no deleted Instances.
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0x00000000; // ModifiedInstanceCount - There are no modified Instances.
		pb += sizeof(DWORD);
		*(DWORD*)pb = SystemTimeToRTime(lpstStartDateLocal); // StartDate
		pb += sizeof(DWORD);
		*(DWORD*)pb = SystemTimeToRTime(lpstEndDateLocal); // EndDate
		pb += sizeof(DWORD);

		// Remainder of Appointment Recurrence Pattern structure
		*(DWORD*)pb = 0x00003006; // ReaderVersion
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0x00003009; // WriterVersion
		pb += sizeof(DWORD);
		*(DWORD*)pb = dwStartOffsetLocal; // StartTimeOffset
		pb += sizeof(DWORD);
		*(DWORD*)pb = dwEndOffsetLocal; // EndTimeOffset
		pb += sizeof(DWORD);
		*(WORD*)pb = 0; // ExceptionCount
		pb += sizeof(WORD);
		*(DWORD*)pb = 0; // ReservedBlock1Size
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0; // ReservedBlock2Size
		pb += sizeof(DWORD);

		// Return it
		*lpcbRecur = cbRecur;
		*lppRecur = (LPBYTE) lpRecur;
		return S_OK;
	}

	return MAPI_E_CALL_FAILED;
}

// Allocates with new, free with delete
// The following code builds a recurrence pattern
HRESULT BuildGlobalObjectId(
							ULONG* lpcbGlobalObjectId,
							LPBYTE* lppGlobalObjectId)
{
	if (!lpcbGlobalObjectId || !lppGlobalObjectId) return MAPI_E_INVALID_PARAMETER;

	// Calculate how large our Global Object Id will be
	size_t cbGlobalObjectId = sizeof(DWORD)*4 + // Byte Array ID
		sizeof(BYTE)*4 + // Year High, Year Low, Month, Day
		sizeof(FILETIME) + // Creation Time
		sizeof(DWORD)*2 + // X
		sizeof(DWORD) + // Size
		sizeof(GUID); // Data

	// Allocate our buffer
	LPBYTE lpGlobalObjectId = new BYTE[cbGlobalObjectId];

	// Populate it
	if (lpGlobalObjectId)
	{
		memset(lpGlobalObjectId,0,cbGlobalObjectId);

		LPBYTE pb = lpGlobalObjectId;
		// Recurrence Pattern sub-structure
		*(DWORD*)pb = 0x00000004; // Byte Array 1
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0x00E00082; // Byte Array 2
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0x10B7C574; // Byte Array 3
		pb += sizeof(DWORD);
		*(DWORD*)pb = 0x08E0821A; // Byte Array 4
		pb += sizeof(DWORD);
		*(BYTE*)pb = 0; // Year High
		pb += sizeof(BYTE);
		*(BYTE*)pb = 0; // Year Low
		pb += sizeof(BYTE);
		*(BYTE*)pb = 0; // Month
		pb += sizeof(BYTE);
		*(BYTE*)pb = 0; // Day
		pb += sizeof(BYTE);

		FILETIME ftNow = {0};
		GetSystemTimeAsFileTime (&ftNow);
		*(FILETIME*)pb = ftNow; // Creation Time
		pb += sizeof(FILETIME);

		*(LONGLONG*)pb = 0; // X
		pb += sizeof(LONGLONG);
		*(DWORD*)pb = sizeof(GUID); // Size
		pb += sizeof(DWORD);

		GUID guid = {0};
		CoCreateGuid(&guid);
		*(GUID*)pb = guid; // Data
		pb += sizeof(GUID);

		// Return it
		*lpcbGlobalObjectId = cbGlobalObjectId;
		*lppGlobalObjectId = (LPBYTE) lpGlobalObjectId;
		return S_OK;
	}

	return MAPI_E_CALL_FAILED;
}

// The array is the list of named properties to be set.
ULONG aulAppointmentProps[] = {
	PidLidAppointmentSequence,
	PidLidBusyStatus,
	PidLidLocation,
	PidLidAppointmentStartWhole,
	PidLidAppointmentEndWhole,
	PidLidAppointmentDuration,
	PidLidAppointmentColor,
	PidLidResponseStatus,
	PidLidRecurring,
	PidLidClipStart,
	PidLidClipEnd,
	PidLidTimeZoneStruct,
	PidLidTimeZoneDescription,
	PidLidAppointmentTimeZoneDefinitionRecur,
	PidLidAppointmentTimeZoneDefinitionStartDisplay,
	PidLidAppointmentTimeZoneDefinitionEndDisplay,
	PidLidAppointmentRecur,
	PidLidRecurrenceType,
	PidLidRecurrencePattern,
	// PSETID_Meeting
	PidLidIsRecurring,
	PidLidGlobalObjectId,
	PidLidCleanGlobalObjectId,
	// PSETID_Common
	PidLidCommonStart,
	PidLidCommonEnd,
	PidLidSideEffects,
};
#define ulAppointmentProps (sizeof(aulAppointmentProps)/sizeof(aulAppointmentProps [0]))

// The enum is to aid in building the property values for SetProps.
// The beginning of the list must match aulAppointmentProps. All non-named properties must come at the end.
enum {
	p_PidLidAppointmentSequence,
	p_PidLidBusyStatus,
	p_PidLidLocation,
	p_PidLidAppointmentStartWhole,
	p_PidLidAppointmentEndWhole,
	p_PidLidAppointmentDuration,
	p_PidLidAppointmentColor,
	p_PidLidResponseStatus,
	p_PidLidRecurring,
	p_PidLidClipStart,
	p_PidLidClipEnd,
	p_PidLidTimeZoneStruct,
	p_PidLidTimeZoneDescription,
	p_PidLidAppointmentTimeZoneDefinitionRecur,
	p_PidLidAppointmentTimeZoneDefinitionStartDisplay,
	p_PidLidAppointmentTimeZoneDefinitionEndDisplay,
	p_PidLidAppointmentRecur,
	p_PidLidRecurrenceType,
	p_PidLidRecurrencePattern,
	p_PidLidIsRecurring,
	p_PidLidGlobalObjectId,
	p_PidLidCleanGlobalObjectId,
	p_PidLidCommonStart,
	p_PidLidCommonEnd,
	p_PidLidSideEffects,
	p_PR_SUBJECT_W,
	p_PR_START_DATE,
	p_PR_END_DATE,
	p_PR_MESSAGE_CLASS_W,
	p_PR_ICON_INDEX,
	p_PR_CONVERSATION_INDEX,
	p_PR_MESSAGE_FLAGS,
	NUM_PROPS};

ULONG ulFirstMeetingProp = p_PidLidIsRecurring;
ULONG ulFirstCommonProp = p_PidLidCommonStart;

HRESULT AddAppointment(LPMAPIFOLDER lpFolder,
					   SYSTEMTIME* lpstStartDateLocal, // PidLidAppointmentRecur
					   SYSTEMTIME* lpstEndDateLocal, // PidLidAppointmentRecur
					   SYSTEMTIME* lpstStartFirstUST, // PidLidAppointmentStartWhole, PidLidCommonStart, PR_START_DATE
					   SYSTEMTIME* lpstEndFirstUST, // PidLidAppointmentEndWhole, PidLidCommonEnd, PR_END_DATE
					   SYSTEMTIME* lpszClipStartUST, // PidLidClipStart
					   SYSTEMTIME* lpstClipEndUST, // PidLidClipEnd
					   SYSTEMTIME* lpstFirstDOW, // PidLidAppointmentRecur
					   DWORD dwStartOffsetLocal, // PidLidAppointmentRecur
					   DWORD dwEndOffsetLocal, // PidLidAppointmentRecur
					   DWORD dwPeriod, // PidLidAppointmentRecur
					   DWORD dwOccurrenceCount, // PidLidAppointmentRecur
					   DWORD dwPatternTypeSpecific, // PidLidAppointmentRecur
					   ULONG ulDuration, // PidLidAppointmentDuration
					   LPWSTR szSubject, // PR_SUBJECT_W
					   LPWSTR szLocation, // PidLidLocation
					   LPWSTR szPattern) // PidLidRecurrencePattern
{
	if (!lpFolder) return MAPI_E_INVALID_PARAMETER;
	HRESULT hRes = S_OK;
	LPMESSAGE lpMessage = 0;
	// create a message and set its properties
	hRes = lpFolder->CreateMessage(0,
		0,
		&lpMessage);
	if (SUCCEEDED(hRes))
	{
		MAPINAMEID  rgnmid[ulAppointmentProps];
		LPMAPINAMEID rgpnmid[ulAppointmentProps];
		LPSPropTagArray lpNamedPropTags = NULL;

		ULONG i = 0;
		for (i = 0 ; i < ulAppointmentProps ; i++)
		{
			if (i < ulFirstMeetingProp)
				rgnmid[i].lpguid = (LPGUID)&PSETID_Appointment;
			else if (i < ulFirstCommonProp)
				rgnmid[i].lpguid = (LPGUID)&PSETID_Meeting;
			else
				rgnmid[i].lpguid = (LPGUID)&PSETID_Common;
			rgnmid[i].ulKind = MNID_ID;
			rgnmid[i].Kind.lID = aulAppointmentProps[i];
			rgpnmid[i] = &rgnmid[i];
		}

		hRes = lpFolder->GetIDsFromNames(
			ulAppointmentProps,
			(LPMAPINAMEID*) &rgpnmid,
			NULL,
			&lpNamedPropTags);
		if (SUCCEEDED(hRes) && lpNamedPropTags)
		{
			// Since we know in advance which props we'll be setting, we can statically declare most of the structures involved and save expensive MAPIAllocateBuffer calls
			SPropValue spvProps[NUM_PROPS] = {0};
			spvProps[p_PidLidAppointmentSequence].ulPropTag                       = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAppointmentSequence],PT_LONG);
			spvProps[p_PidLidBusyStatus].ulPropTag                                = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidBusyStatus],PT_LONG);
			spvProps[p_PidLidLocation].ulPropTag                                  = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidLocation],PT_UNICODE);
			spvProps[p_PidLidAppointmentStartWhole].ulPropTag                     = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAppointmentStartWhole],PT_SYSTIME);
			spvProps[p_PidLidAppointmentEndWhole].ulPropTag                       = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAppointmentEndWhole],PT_SYSTIME);
			spvProps[p_PidLidAppointmentDuration].ulPropTag                       = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAppointmentDuration],PT_LONG);
			spvProps[p_PidLidAppointmentColor].ulPropTag                          = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAppointmentColor],PT_LONG);
			spvProps[p_PidLidResponseStatus].ulPropTag                            = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidResponseStatus],PT_LONG);
			spvProps[p_PidLidRecurring].ulPropTag                                 = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidRecurring],PT_BOOLEAN);
			spvProps[p_PidLidClipStart].ulPropTag                                 = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidClipStart],PT_SYSTIME);
			spvProps[p_PidLidClipEnd].ulPropTag                                   = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidClipEnd],PT_SYSTIME);
			spvProps[p_PidLidTimeZoneStruct].ulPropTag                            = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTimeZoneStruct],PT_BINARY);
			spvProps[p_PidLidTimeZoneDescription].ulPropTag                       = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidTimeZoneDescription],PT_UNICODE);
			spvProps[p_PidLidAppointmentTimeZoneDefinitionRecur].ulPropTag        = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAppointmentTimeZoneDefinitionRecur],PT_BINARY);
			spvProps[p_PidLidAppointmentTimeZoneDefinitionStartDisplay].ulPropTag = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAppointmentTimeZoneDefinitionStartDisplay],PT_BINARY);
			spvProps[p_PidLidAppointmentTimeZoneDefinitionEndDisplay].ulPropTag   = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAppointmentTimeZoneDefinitionEndDisplay],PT_BINARY);
			spvProps[p_PidLidAppointmentRecur].ulPropTag                          = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidAppointmentRecur],PT_BINARY);
			spvProps[p_PidLidRecurrenceType].ulPropTag                            = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidRecurrenceType],PT_LONG);
			spvProps[p_PidLidRecurrencePattern].ulPropTag                         = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidRecurrencePattern],PT_UNICODE);
			spvProps[p_PidLidIsRecurring].ulPropTag                               = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidIsRecurring],PT_BOOLEAN);
			spvProps[p_PidLidGlobalObjectId].ulPropTag                            = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidGlobalObjectId],PT_BINARY);
			spvProps[p_PidLidCleanGlobalObjectId].ulPropTag                       = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidCleanGlobalObjectId],PT_BINARY);
			spvProps[p_PidLidCommonStart].ulPropTag                               = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidCommonStart],PT_SYSTIME);
			spvProps[p_PidLidCommonEnd].ulPropTag                                 = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidCommonEnd],PT_SYSTIME);
			spvProps[p_PidLidSideEffects].ulPropTag                               = CHANGE_PROP_TYPE(lpNamedPropTags->aulPropTag[p_PidLidSideEffects],PT_LONG);

			spvProps[p_PR_SUBJECT_W].ulPropTag		    = PR_SUBJECT_W;
			spvProps[p_PR_START_DATE].ulPropTag         = PR_START_DATE;
			spvProps[p_PR_END_DATE].ulPropTag           = PR_END_DATE;
			spvProps[p_PR_MESSAGE_CLASS_W].ulPropTag    = PR_MESSAGE_CLASS_W;
			spvProps[p_PR_ICON_INDEX].ulPropTag         = PR_ICON_INDEX;
			spvProps[p_PR_CONVERSATION_INDEX].ulPropTag	= PR_CONVERSATION_INDEX;
			spvProps[p_PR_MESSAGE_FLAGS].ulPropTag      = PR_MESSAGE_FLAGS;

			spvProps[p_PidLidAppointmentSequence].Value.l = 0;
			spvProps[p_PidLidBusyStatus].Value.l = olBusy;
			spvProps[p_PidLidLocation].Value.lpszW = szLocation;
			SystemTimeToFileTime(lpstStartFirstUST,&spvProps[p_PidLidAppointmentStartWhole].Value.ft);
			SystemTimeToFileTime(lpstEndFirstUST,&spvProps[p_PidLidAppointmentEndWhole].Value.ft);
			spvProps[p_PidLidAppointmentDuration].Value.l = ulDuration;
			spvProps[p_PidLidAppointmentColor].Value.l = 0; // No color
			spvProps[p_PidLidResponseStatus].Value.l = respNone;
			spvProps[p_PidLidRecurring].Value.b = true;
			SystemTimeToFileTime(lpszClipStartUST,&spvProps[p_PidLidClipStart].Value.ft);
			SystemTimeToFileTime(lpstClipEndUST,&spvProps[p_PidLidClipEnd].Value.ft);

			SYSTEMTIME stStandard = {0};
			stStandard.wMonth = 0xB;
			stStandard.wDay = 0x1;
			stStandard.wHour = 0x2;
			SYSTEMTIME stDaylight = {0};
			stDaylight.wMonth = 0x3;
			stDaylight.wDay = 0x2;
			stDaylight.wHour = 0x2;
			hRes = BuildTimeZoneStruct(
				300,
				0,
				(DWORD)-60,
				&stStandard,
				&stDaylight,
				&spvProps[p_PidLidTimeZoneStruct].Value.bin.cb,
				&spvProps[p_PidLidTimeZoneStruct].Value.bin.lpb);
			spvProps[p_PidLidTimeZoneDescription].Value.lpszW = L"(GMT-05:00) Eastern Time (US & Canada)";
			SYSTEMTIME stRule1Standard = {0};
			stRule1Standard.wMonth = 0xA;
			stRule1Standard.wDay = 0x5;
			stRule1Standard.wHour = 0x2;
			SYSTEMTIME stRule1Daylight = {0};
			stRule1Daylight.wMonth = 0x4;
			stRule1Daylight.wDay = 0x1;
			stRule1Daylight.wHour = 0x2;
			if (SUCCEEDED(hRes)) hRes = BuildTimeZoneDefinition(
				L"Eastern Standard Time",
				0, // TZRule Flags
				2006, // wYear
				300, // lbias
				0, // lStandardBias,
				(DWORD)-60, // lDaylightBias,
				&stRule1Standard, // stStandardDate
				&stRule1Daylight, // stDaylightDate
				TZRULE_FLAG_EFFECTIVE_TZREG, // TZRule Flags
				2007, // wYear
				300, // lbias
				0, // lStandardBias,
				(DWORD)-60, // lDaylightBias,
				&stStandard, // stStandardDate
				&stDaylight, // stDaylightDate
				&spvProps[p_PidLidAppointmentTimeZoneDefinitionRecur].Value.bin.cb,
				&spvProps[p_PidLidAppointmentTimeZoneDefinitionRecur].Value.bin.lpb);
			spvProps[p_PidLidAppointmentTimeZoneDefinitionStartDisplay].Value.bin.cb  = spvProps[p_PidLidAppointmentTimeZoneDefinitionRecur].Value.bin.cb;
			spvProps[p_PidLidAppointmentTimeZoneDefinitionStartDisplay].Value.bin.lpb = spvProps[p_PidLidAppointmentTimeZoneDefinitionRecur].Value.bin.lpb;
			spvProps[p_PidLidAppointmentTimeZoneDefinitionEndDisplay].Value.bin.cb  = spvProps[p_PidLidAppointmentTimeZoneDefinitionRecur].Value.bin.cb;
			spvProps[p_PidLidAppointmentTimeZoneDefinitionEndDisplay].Value.bin.lpb = spvProps[p_PidLidAppointmentTimeZoneDefinitionRecur].Value.bin.lpb;
			if (SUCCEEDED(hRes)) hRes = BuildWeeklyAppointmentRecurrencePattern(
				lpstStartDateLocal,
				lpstEndDateLocal,
				lpstFirstDOW,
				dwStartOffsetLocal,
				dwEndOffsetLocal,
				dwPeriod,
				dwOccurrenceCount,
				dwPatternTypeSpecific,
				&spvProps[p_PidLidAppointmentRecur].Value.bin.cb,
				&spvProps[p_PidLidAppointmentRecur].Value.bin.lpb);
			spvProps[p_PidLidRecurrenceType].Value.l = rectypeWeekly;
			spvProps[p_PidLidRecurrencePattern].Value.lpszW = szPattern;
			spvProps[p_PidLidIsRecurring].Value.b = true;
			if (SUCCEEDED(hRes)) hRes = BuildGlobalObjectId(
				&spvProps[p_PidLidGlobalObjectId].Value.bin.cb,
				&spvProps[p_PidLidGlobalObjectId].Value.bin.lpb);
			spvProps[p_PidLidCleanGlobalObjectId].Value.bin.cb  = spvProps[p_PidLidGlobalObjectId].Value.bin.cb;
			spvProps[p_PidLidCleanGlobalObjectId].Value.bin.lpb = spvProps[p_PidLidGlobalObjectId].Value.bin.lpb;
			SystemTimeToFileTime(lpstStartFirstUST,&spvProps[p_PidLidCommonStart].Value.ft);
			SystemTimeToFileTime(lpstEndFirstUST,&spvProps[p_PidLidCommonEnd].Value.ft);
			spvProps[p_PidLidSideEffects].Value.l = seOpenToDelete | seOpenToCopy | seOpenToMove | seCoerceToInbox | seOpenForCtxMenu;

			spvProps[p_PR_SUBJECT_W].Value.lpszW = szSubject;
			SystemTimeToFileTime(lpstStartFirstUST,&spvProps[p_PR_START_DATE].Value.ft);
			SystemTimeToFileTime(lpstEndFirstUST,&spvProps[p_PR_END_DATE].Value.ft);
			spvProps[p_PR_MESSAGE_CLASS_W].Value.lpszW = L"IPM.Appointment";
			spvProps[p_PR_ICON_INDEX].Value.l = 0x00000401; // Recurring Appointment
			if (SUCCEEDED(hRes)) hRes = BuildConversationIndex(
				&spvProps[p_PR_CONVERSATION_INDEX].Value.bin.cb,
				&spvProps[p_PR_CONVERSATION_INDEX].Value.bin.lpb);
			spvProps[p_PR_MESSAGE_FLAGS].Value.l = MSGFLAG_READ;

			if (SUCCEEDED(hRes)) hRes = lpMessage->SetProps(NUM_PROPS, spvProps, NULL);
			if (SUCCEEDED(hRes))
			{
				hRes = lpMessage->SaveChanges(FORCE_SAVE);
			}
			if (spvProps[p_PidLidTimeZoneStruct].Value.bin.lpb)
				delete[] spvProps[p_PidLidTimeZoneStruct].Value.bin.lpb;
			if (spvProps[p_PidLidAppointmentTimeZoneDefinitionRecur].Value.bin.lpb)
				delete[] spvProps[p_PidLidAppointmentTimeZoneDefinitionRecur].Value.bin.lpb;
			// Do not delete p_PidLidAppointmentTimeZoneDefinitionStartDisplay, it was borrowed from p_PidLidAppointmentTimeZoneDefinitionStartDisplay
			// Do not delete p_PidLidAppointmentTimeZoneDefinitionEndDisplay, it was borrowed from p_PidLidAppointmentTimeZoneDefinitionStartDisplay
			if (spvProps[p_PidLidAppointmentRecur].Value.bin.lpb)
				delete[] spvProps[p_PidLidAppointmentRecur].Value.bin.lpb;
			if (spvProps[p_PidLidGlobalObjectId].Value.bin.lpb)
				delete[] spvProps[p_PidLidGlobalObjectId].Value.bin.lpb;
			// Do not delete p_PidLidCleanGlobalObjectId, it was borrowed from p_PidLidGlobalObjectId
			if (spvProps[p_PR_CONVERSATION_INDEX].Value.bin.lpb)
				delete[] spvProps[p_PR_CONVERSATION_INDEX].Value.bin.lpb;
		}
		MAPIFreeBuffer(lpNamedPropTags);
	}
	if (lpMessage) lpMessage->Release();
	return hRes;
}

_AddInDialogControl g_AppointmentControls[] =
{
	// {type,readonly,multiline,defaultcheckstate,defaultvalue(number),text label,defaultvalue(text),cbBin,lpBin}
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Subject", L"This is a sample appointment",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Location", L"MAPI Land",0,0},
};
void DisplayAddAppointmentDialog(LPMAPIFOLDER lpFolder)
{
	LPCOMPLEXDIALOG pfnComplexDialog = (LPCOMPLEXDIALOG) GetProcAddress(GetModuleHandle(NULL),szComplexDialog);
	LPFREEDIALOGRESULT pfnFreeDialogResult = (LPFREEDIALOGRESULT) GetProcAddress(GetModuleHandle(NULL),szFreeDialogResult);
	if (pfnComplexDialog && pfnFreeDialogResult)
	{
		_AddInDialog myDialog = {0};
		myDialog.szTitle = L"Add Appointment";
		myDialog.szPrompt = L"Thus function creates a recurring appointment in the current folder\r\n"
			L"\twith the following recurrence pattern:\r\n"
			L"Type: Weekly, every Friday for 10 weeks\r\n"
			L"Time: 9 AM to 10 AM, (GMT-05:00) Eastern Time (US & Canada)\r\n"
			L"Date: January 9th, 2009 to March 13th, 2009\r\n"
			L"\r\n"
			L"Fill out the subject and location of your appointment.";
		myDialog.ulButtonFlags = CEDITOR_BUTTON_OK;
		myDialog.ulNumControls = sizeof(g_AppointmentControls)/sizeof(_AddInDialogControl);
		myDialog.lpDialogControls = g_AppointmentControls;

		LPADDINDIALOGRESULT lpDialogResult = NULL;

		pfnComplexDialog(&myDialog,&lpDialogResult);
		if (lpDialogResult)
		{
			ULONG i = 0;
			LPWSTR szSubject = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szLocation = lpDialogResult->lpDialogControlResults[i++].szText;

			// Date of first instance
			SYSTEMTIME stStartDateLocal = {0};
			stStartDateLocal.wYear = 2009;
			stStartDateLocal.wMonth = 1;
			stStartDateLocal.wDay = 9;

			// Date of last instance
			SYSTEMTIME stEndDateLocal = {0};
			stEndDateLocal.wYear = 2009;
			stEndDateLocal.wMonth = 3;
			stEndDateLocal.wDay = 13;

			// Date of start of first instance
			SYSTEMTIME stStartFirstUST = {0};
			stStartFirstUST.wYear = 2009;
			stStartFirstUST.wMonth = 1;
			stStartFirstUST.wDay = 9;
			stStartFirstUST.wHour = 14;

			// Date of end of first instance
			SYSTEMTIME stEndFirstUST = {0};
			stEndFirstUST.wYear = 2009;
			stEndFirstUST.wMonth = 1;
			stEndFirstUST.wDay = 9;
			stEndFirstUST.wHour = 15;

			SYSTEMTIME szClipStartUST = {0};
			szClipStartUST.wYear = 2009;
			szClipStartUST.wMonth = 1;
			szClipStartUST.wDay = 9;
			szClipStartUST.wHour = 5;

			SYSTEMTIME stClipEndUST = {0};
			stClipEndUST.wYear = 2009;
			stClipEndUST.wMonth = 3;
			stClipEndUST.wDay = 13;
			stClipEndUST.wHour = 4;

			// We're hard coding Sunday as our FirstDOW, so this is the first DOW before the start date
			SYSTEMTIME stFirstDOW = {0};
			stFirstDOW.wYear = 2009;
			stFirstDOW.wMonth = 1;
			stFirstDOW.wDay = 4;

			DWORD dwPeriod = 1; // Every 1 week
			DWORD dwOccurrenceCount = 10; // 2 occurrences
			DWORD dwPatternTypeSpecific = rdfFri; // On Fridays
			ULONG ulDuration = 60;

			DWORD dwStartOffsetLocal = 9*60;
			DWORD dwEndOffsetLocal = 10*60;

			(void) AddAppointment(lpFolder,
				&stStartDateLocal,
				&stEndDateLocal,
				&stStartFirstUST,
				&stEndFirstUST,
				&szClipStartUST,
				&stClipEndUST,
				&stFirstDOW,
				dwStartOffsetLocal,
				dwEndOffsetLocal,
				dwPeriod,
				dwOccurrenceCount,
				dwPatternTypeSpecific,
				ulDuration,
				szSubject,
				szLocation,
				L"every Friday from 9:00 AM to 10:00 AM");
		}
		pfnFreeDialogResult(lpDialogResult);
	}
}
