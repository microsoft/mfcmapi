#pragma once

void DisplayAddTaskDialog(LPMAPIFOLDER lpFolder);