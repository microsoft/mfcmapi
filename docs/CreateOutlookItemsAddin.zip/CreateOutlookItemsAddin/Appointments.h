#pragma once

void DisplayAddAppointmentDialog(LPMAPIFOLDER lpFolder);