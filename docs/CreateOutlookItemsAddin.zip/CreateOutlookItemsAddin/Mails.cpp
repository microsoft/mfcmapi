#include "CreateOutlookItemsAddin.h"
#include <initguid.h>

// So we can call AddInLog
extern LPADDINLOG AddInLog;

#define PR_INETMAIL_OVERRIDE_FORMAT PROP_TAG(PT_LONG, 0x5902)
#define cpidASCII 20127

HRESULT HrAllocAdrList(ULONG ulNumProps, LPADRLIST* lpAdrList)
{
	if (!lpAdrList || ulNumProps > ULONG_MAX/sizeof(SPropValue)) return MAPI_E_INVALID_PARAMETER;
	HRESULT hRes = S_OK;
	LPADRLIST lpLocalAdrList = NULL;

	*lpAdrList = NULL;

	// Allocate memory for new SRowSet structure.
	hRes = MAPIAllocateBuffer(CbNewSRowSet(1),(LPVOID*) &lpLocalAdrList);

	if (SUCCEEDED(hRes) && lpLocalAdrList)
	{
		// Zero out allocated memory.
		ZeroMemory(lpLocalAdrList, CbNewSRowSet(1));

		// Allocate memory for SPropValue structure that indicates what
		// recipient properties will be set.
		hRes = MAPIAllocateBuffer(
			ulNumProps * sizeof(SPropValue),
			(LPVOID*) &lpLocalAdrList->aEntries[0].rgPropVals);

		if (SUCCEEDED(hRes) && lpLocalAdrList->aEntries[0].rgPropVals)
		{
			// Zero out allocated memory.
			ZeroMemory(lpLocalAdrList->aEntries[0].rgPropVals,ulNumProps * sizeof(SPropValue));
			*lpAdrList = lpLocalAdrList;
		}
		else
		{
			MAPIFreeBuffer(lpLocalAdrList);
		}
	}

	return hRes;
}

// The enum is to aid in building the property values for ResolveName/ModifyRecipients
enum {
	p_PR_DISPLAY_NAME_W,
	p_PR_RECIPIENT_TYPE,
	NUM_RECIP_PROPS};

HRESULT AddRecipient(LPMAPISESSION lpMAPISession,
					 LPMESSAGE lpMessage,
					 ULONG ulRecipientType,
					 LPWSTR szRecipientName)
{
	HRESULT			hRes	= S_OK;
	LPADRLIST		lpAdrList = NULL;  // ModifyRecips takes LPADRLIST
	LPADRBOOK		lpAddrBook = NULL;

	if (!lpMessage || !lpMAPISession) return MAPI_E_INVALID_PARAMETER;

	hRes = lpMAPISession->OpenAddressBook(
		NULL,
		NULL,
		NULL,
		&lpAddrBook);
	if (SUCCEEDED(hRes) && lpAddrBook)
	{
		hRes = HrAllocAdrList(NUM_RECIP_PROPS,&lpAdrList);
		if (SUCCEEDED(hRes) && lpAdrList)
		{
			// Set up the recipient by indicating how many recipients
			// and how many properties will be set on each recipient.
			lpAdrList->cEntries = 1;	// How many recipients.
			lpAdrList->aEntries[0].cValues = NUM_RECIP_PROPS;  // How many properties per recipient

			lpAdrList->aEntries[0].rgPropVals[p_PR_DISPLAY_NAME_W].ulPropTag = PR_DISPLAY_NAME_W;
			lpAdrList->aEntries[0].rgPropVals[p_PR_RECIPIENT_TYPE].ulPropTag = PR_RECIPIENT_TYPE;

			lpAdrList->aEntries[0].rgPropVals[p_PR_DISPLAY_NAME_W].Value.lpszW =  szRecipientName;
			lpAdrList->aEntries[0].rgPropVals[p_PR_RECIPIENT_TYPE].Value.l = ulRecipientType;

			hRes = lpAddrBook->ResolveName(
				0L,
				MAPI_UNICODE,
				NULL,
				lpAdrList);
			AddInLog(true,L"CallMenu: ResolveName - returned hRes = 0x%08X\n",hRes);
			if (SUCCEEDED(hRes))
			{
				// If everything goes right, add the new recipient to the message
				// object passed into us.
				hRes = lpMessage->ModifyRecipients(MODRECIP_ADD,lpAdrList);
			}
		}
	}
	if (lpAdrList) FreePadrlist(lpAdrList);
	if (lpAddrBook) lpAddrBook->Release();
	return hRes;
}

// Allocates with new, free with delete[]
HRESULT BuildReportTag(ULONG cbStoreEntryID,
					   LPBYTE lpStoreEntryID,
					   ULONG cbFolderEntryID,
					   LPBYTE lpFolderEntryID,
					   ULONG cbMessageEntryID,
					   LPBYTE lpMessageEntryID,
					   ULONG cbSearchFolderEntryID,
					   LPBYTE lpSearchFolderEntryID,
					   ULONG cbMessageSearchKey, // MUST not be NULL
					   LPBYTE lpMessageSearchKey, // MUST not be NULL
					   LPSTR lpszAnsiText,
					   ULONG* lpcbReportTag,
					   LPBYTE* lppReportTag)
{
	if (!lpcbReportTag || !lppReportTag || !cbMessageSearchKey || !lpMessageSearchKey) return MAPI_E_INVALID_PARAMETER;

	*lpcbReportTag = NULL;
	*lppReportTag = NULL;

	size_t cchAnsiText = NULL;
	if (lpszAnsiText) cchAnsiText = strlen(lpszAnsiText) + 1; // Count the NULL terminator

	// Calculate how large our struct will be
	size_t cbStruct = 9* sizeof(CHAR) + // Cookie
		sizeof(DWORD) + // Version
		sizeof(DWORD) + // cbStoreEntryID
		cbStoreEntryID + // lpStoreEntryID
		sizeof(DWORD) + // cbFolderEntryID
		cbFolderEntryID + // lpFolderEntryID
		sizeof(DWORD) + // cbMessageEntryID
		cbMessageEntryID + // lpMessageEntryID
		sizeof(DWORD) + // cbSearchFolderEntryID
		cbSearchFolderEntryID + // lpSearchFolderEntryID
		sizeof(DWORD) + // cbMessageSearchKey
		cbMessageSearchKey + // lpMessageSearchKey
		sizeof(DWORD) + // cchAnsiText
		cchAnsiText; // lpszAnsiText

	// Allocate our buffer
	LPBYTE lpReportTag = new BYTE[cbStruct];

	// Populate it
	if (lpReportTag)
	{
		memset(lpReportTag,0,cbStruct);

		LPBYTE pb = lpReportTag;
		// this will copy the string and the NULL terminator together
		memcpy(pb,"PCDFEB09",9);
		pb += 9;
		*(WORD*)pb = 0x0001;
		pb += sizeof(WORD);
		*(WORD*)pb = 0x0002;
		pb += sizeof(WORD);
		*((DWORD*)pb) = cbStoreEntryID;
		pb += sizeof(DWORD);
		if (cbStoreEntryID)
		{
			memcpy(pb,lpStoreEntryID,cbStoreEntryID);
			pb += cbStoreEntryID;
		}
		*((DWORD*)pb) = cbFolderEntryID;
		pb += sizeof(DWORD);
		if (cbFolderEntryID)
		{
			memcpy(pb,lpFolderEntryID,cbFolderEntryID);
			pb += cbFolderEntryID;
		}
		*((DWORD*)pb) = cbMessageEntryID;
		pb += sizeof(DWORD);
		if (cbMessageEntryID)
		{
			memcpy(pb,lpMessageEntryID,cbMessageEntryID);
			pb += cbMessageEntryID;
		}
		*((DWORD*)pb) = cbSearchFolderEntryID;
		pb += sizeof(DWORD);
		if (cbSearchFolderEntryID)
		{
			memcpy(pb,lpSearchFolderEntryID,cbSearchFolderEntryID);
			pb += cbSearchFolderEntryID;
		}
		*((DWORD*)pb) = cbMessageSearchKey;
		pb += sizeof(DWORD);
		if (cbMessageSearchKey)
		{
			memcpy(pb,lpMessageSearchKey,cbMessageSearchKey);
			pb += cbMessageSearchKey;
		}
		*((DWORD*)pb) = cchAnsiText;
		pb += sizeof(DWORD);
		if (cchAnsiText)
		{
			memcpy(pb,lpszAnsiText,cchAnsiText * sizeof(CHAR));
			pb += cchAnsiText * sizeof(CHAR);
		}

		// Return it
		*lpcbReportTag = cbStruct;
		*lppReportTag = lpReportTag;
		return S_OK;
	}

	return MAPI_E_CALL_FAILED;
}

HRESULT AddReportTag(LPMESSAGE lpMessage)
{
	if (!lpMessage) return MAPI_E_INVALID_PARAMETER;
	HRESULT hRes = S_OK;
	ULONG cValues = 0;
	LPSPropValue lpPropArray = NULL;

	SizedSPropTagArray(2, sptaProps) = {2,{PR_PARENT_ENTRYID,PR_SEARCH_KEY}};

	hRes = lpMessage->GetProps((LPSPropTagArray)&sptaProps, 0, &cValues, &lpPropArray);
	if (SUCCEEDED(hRes))
	{
		SPropValue sProp = {0};
		sProp.ulPropTag = PR_REPORT_TAG;
		hRes = BuildReportTag(NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			(lpPropArray[0].ulPropTag == PR_PARENT_ENTRYID)?lpPropArray[0].Value.bin.cb:0,
			(lpPropArray[0].ulPropTag == PR_PARENT_ENTRYID)?lpPropArray[0].Value.bin.lpb:0,
			(lpPropArray[1].ulPropTag == PR_SEARCH_KEY)?lpPropArray[1].Value.bin.cb:0,
			(lpPropArray[1].ulPropTag == PR_SEARCH_KEY)?lpPropArray[1].Value.bin.lpb:0,
			"",
			&sProp.Value.bin.cb,
			&sProp.Value.bin.lpb);
		if (SUCCEEDED(hRes) && sProp.Value.bin.cb && sProp.Value.bin.lpb)
		{
			hRes = lpMessage->SetProps(1,&sProp,NULL);
		}
		delete[] sProp.Value.bin.lpb;
	}

	return hRes;
}

// The enum is to aid in building the property values for SetProps.
enum {
	p_PR_MESSAGE_CLASS_W,
	p_PR_ICON_INDEX,
	p_PR_SUBJECT_W,
	p_PR_CONVERSATION_TOPIC_W,
	p_PR_BODY_W,
	p_PR_IMPORTANCE,
	p_PR_READ_RECEIPT_REQUESTED,
	p_PR_MESSAGE_FLAGS,
	p_PR_MSG_EDITOR_FORMAT,
	p_PR_MESSAGE_LOCALE_ID,
	p_PR_INETMAIL_OVERRIDE_FORMAT,
	p_PR_DELETE_AFTER_SUBMIT,
	p_PR_INTERNET_CPID,
	p_PR_CONVERSATION_INDEX,
	NUM_PROPS};

HRESULT AddMail(LPMAPISESSION lpMAPISession,
				LPMAPIFOLDER lpFolder,
				LPWSTR szSubject, // PR_SUBJECT_W, PR_CONVERSATION_TOPIC
				LPWSTR szBody, // PR_BODY_W
				LPWSTR szRecipientName, // Recipient table
				BOOL bHighImportance, // PR_IMPORTANCE
				BOOL bReadReceipt, // PR_READ_RECEIPT_REQUESTED
				BOOL bSubmit,
				BOOL bDeleteAfterSubmit)
{
	if (!lpFolder) return MAPI_E_INVALID_PARAMETER;
	HRESULT hRes = S_OK;
	LPMESSAGE lpMessage = 0;

	// Create a message and set its properties
	hRes = lpFolder->CreateMessage(0,
		0,
		&lpMessage);
	if (SUCCEEDED(hRes))
	{
		// Since we know in advance which props we'll be setting, we can statically declare most of the structures involved and save expensive MAPIAllocateBuffer calls
		SPropValue spvProps[NUM_PROPS] = {0};
		spvProps[p_PR_MESSAGE_CLASS_W].ulPropTag          = PR_MESSAGE_CLASS_W;
		spvProps[p_PR_ICON_INDEX].ulPropTag	              = PR_ICON_INDEX;
		spvProps[p_PR_SUBJECT_W].ulPropTag                = PR_SUBJECT_W;
		spvProps[p_PR_CONVERSATION_TOPIC_W].ulPropTag     = PR_CONVERSATION_TOPIC_W;
		spvProps[p_PR_BODY_W].ulPropTag                   = PR_BODY_W;
		spvProps[p_PR_IMPORTANCE].ulPropTag               = PR_IMPORTANCE;
		spvProps[p_PR_READ_RECEIPT_REQUESTED].ulPropTag   = PR_READ_RECEIPT_REQUESTED;
		spvProps[p_PR_MESSAGE_FLAGS].ulPropTag	          = PR_MESSAGE_FLAGS;
		spvProps[p_PR_MSG_EDITOR_FORMAT].ulPropTag	      = PR_MSG_EDITOR_FORMAT;
		spvProps[p_PR_MESSAGE_LOCALE_ID].ulPropTag	      = PR_MESSAGE_LOCALE_ID;
		spvProps[p_PR_INETMAIL_OVERRIDE_FORMAT].ulPropTag = PR_INETMAIL_OVERRIDE_FORMAT;
		spvProps[p_PR_DELETE_AFTER_SUBMIT].ulPropTag      = PR_DELETE_AFTER_SUBMIT;
		spvProps[p_PR_INTERNET_CPID].ulPropTag            = PR_INTERNET_CPID;
		spvProps[p_PR_CONVERSATION_INDEX].ulPropTag	      = PR_CONVERSATION_INDEX;

		spvProps[p_PR_MESSAGE_CLASS_W].Value.lpszW = L"IPM.Note";
		spvProps[p_PR_ICON_INDEX].Value.l = 0x103; // Unsent Mail
		spvProps[p_PR_SUBJECT_W].Value.lpszW = szSubject;
		spvProps[p_PR_CONVERSATION_TOPIC_W].Value.lpszW = szSubject;
		spvProps[p_PR_BODY_W].Value.lpszW = szBody;
		spvProps[p_PR_IMPORTANCE].Value.l = bHighImportance?IMPORTANCE_HIGH:IMPORTANCE_NORMAL;
		spvProps[p_PR_READ_RECEIPT_REQUESTED].Value.b = bReadReceipt?true:false;
		spvProps[p_PR_MESSAGE_FLAGS].Value.l = MSGFLAG_UNSENT;
		spvProps[p_PR_MSG_EDITOR_FORMAT].Value.l = EDITOR_FORMAT_PLAINTEXT;
		spvProps[p_PR_MESSAGE_LOCALE_ID].Value.l = 1033; // (en-us)
		spvProps[p_PR_INETMAIL_OVERRIDE_FORMAT].Value.l = NULL; // Mail system chooses default encoding scheme
		spvProps[p_PR_DELETE_AFTER_SUBMIT].Value.b = bDeleteAfterSubmit?true:false;
		spvProps[p_PR_INTERNET_CPID].Value.l = cpidASCII;

		hRes = BuildConversationIndex(
			&spvProps[p_PR_CONVERSATION_INDEX].Value.bin.cb,
			&spvProps[p_PR_CONVERSATION_INDEX].Value.bin.lpb);

		if (SUCCEEDED(hRes))
		{
			hRes = lpMessage->SetProps(NUM_PROPS, spvProps, NULL);
			if (SUCCEEDED(hRes))
			{
				hRes = AddRecipient(lpMAPISession,
					lpMessage,
					MAPI_TO,
					szRecipientName);
				AddInLog(true,L"CallMenu: AddRecipient - returned hRes = 0x%08X\n",hRes);
				if (SUCCEEDED(hRes))
				{
					if (bReadReceipt)
					{
						hRes = AddReportTag(lpMessage);
					}

					if (SUCCEEDED(hRes))
					{
						hRes = lpMessage->SaveChanges(KEEP_OPEN_READWRITE);
						if (SUCCEEDED(hRes) && bSubmit)
						{
							hRes = lpMessage->SubmitMessage(NULL);
						}
					}
				}
			}
		}
		if (spvProps[p_PR_CONVERSATION_INDEX].Value.bin.lpb)
			delete[] spvProps[p_PR_CONVERSATION_INDEX].Value.bin.lpb;
	}
	if (lpMessage) lpMessage->Release();
	return hRes;
}

_AddInDialogControl g_MailControls[] =
{
	// {type,readonly,multiline,defaultcheckstate,defaultvalue(number),text label,defaultvalue(text),cbBin,lpBin}
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Subject", L"Order Request",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Body", L"Please sign the order request.",0,0},
	{ADDIN_CTRL_EDIT_TEXT, false, false, false, 0, L"Recipient Name", L"Stephen Griffin",0,0},
	{ADDIN_CTRL_CHECK, false, false, false, 0, L"High Importance", L"",0,0},
	{ADDIN_CTRL_CHECK, false, false, true, 0, L"Read Receipt", L"",0,0},
	{ADDIN_CTRL_CHECK, false, false, true, 0, L"Submit After Create", L"",0,0},
	{ADDIN_CTRL_CHECK, false, false, true, 0, L"Delete After Submit", L"",0,0},
};
void DisplayAddMailDialog(LPMAPISESSION lpMAPISession, LPMAPIFOLDER lpFolder)
{
	LPCOMPLEXDIALOG pfnComplexDialog = (LPCOMPLEXDIALOG) GetProcAddress(GetModuleHandle(NULL),szComplexDialog);
	LPFREEDIALOGRESULT pfnFreeDialogResult = (LPFREEDIALOGRESULT) GetProcAddress(GetModuleHandle(NULL),szFreeDialogResult);
	if (pfnComplexDialog && pfnFreeDialogResult)
	{
		_AddInDialog myDialog = {0};
		myDialog.szTitle = L"Add Mail";
		myDialog.szPrompt = L"Thus function creates a message in the current folder and optionally submits it.\r\n"
			L"\r\n"
			L"Fill out the details of your mail.";
		myDialog.ulButtonFlags = CEDITOR_BUTTON_OK;
		myDialog.ulNumControls = sizeof(g_MailControls)/sizeof(_AddInDialogControl);
		myDialog.lpDialogControls = g_MailControls;

		LPADDINDIALOGRESULT lpDialogResult = NULL;

		pfnComplexDialog(&myDialog,&lpDialogResult);
		if (lpDialogResult)
		{
			ULONG i = 0;
			LPWSTR szSubject = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szBody = lpDialogResult->lpDialogControlResults[i++].szText;
			LPWSTR szRecipientName = lpDialogResult->lpDialogControlResults[i++].szText;
			BOOL bHighImportance = lpDialogResult->lpDialogControlResults[i++].bCheckState;
			BOOL bReadReceipt = lpDialogResult->lpDialogControlResults[i++].bCheckState;
			BOOL bSubmit = lpDialogResult->lpDialogControlResults[i++].bCheckState;
			BOOL bDeleteAfterSubmit = lpDialogResult->lpDialogControlResults[i++].bCheckState;
			(void) AddMail(lpMAPISession,
				lpFolder,
				szSubject,
				szBody,
				szRecipientName,
				bHighImportance,
				bReadReceipt,
				bSubmit,
				bDeleteAfterSubmit);
		}
		pfnFreeDialogResult(lpDialogResult);
	}
}
